(function () {
  try {
    var emberCanvas = document.getElementById("emberCanvas");
    if (emberCanvas && emberCanvas.getContext) {
      var emberContext = emberCanvas.getContext("2d", { alpha: true });
      var embers = [];
      var nextEmber = 0;

      function createEmberSprite(gold) {
        var sprite = document.createElement("canvas");
        sprite.width = 18;
        sprite.height = 32;
        var context = sprite.getContext("2d", { alpha: true });
        var glow = context.createRadialGradient(9, 17, 0, 9, 17, 9);
        glow.addColorStop(
          0,
          gold ? "rgba(255,194,92,.3)" : "rgba(249,94,18,.26)"
        );
        glow.addColorStop(0.48, "rgba(249,115,22,.1)");
        glow.addColorStop(1, "rgba(249,115,22,0)");
        context.fillStyle = glow;
        context.beginPath();
        if (context.ellipse) {
          context.ellipse(9, 17, 8, 13, 0, 0, Math.PI * 2);
        } else {
          context.save();
          context.translate(9, 17);
          context.scale(1, 1.625);
          context.arc(0, 0, 8, 0, Math.PI * 2);
          context.restore();
        }
        context.fill();

        var flame = context.createLinearGradient(9, 5, 9, 27);
        flame.addColorStop(0, "rgba(255,230,170,0)");
        flame.addColorStop(
          0.34,
          gold ? "rgba(255,213,128,.96)" : "rgba(255,151,57,.92)"
        );
        flame.addColorStop(
          0.72,
          gold ? "rgba(255,161,47,.72)" : "rgba(240,69,12,.7)"
        );
        flame.addColorStop(1, "rgba(210,38,5,0)");
        context.fillStyle = flame;
        context.beginPath();
        context.moveTo(9, 4);
        context.bezierCurveTo(13, 11, 12, 20, 9, 28);
        context.bezierCurveTo(6, 21, 5, 12, 9, 4);
        context.fill();
        return sprite;
      }

      var orangeEmber = createEmberSprite(false);
      var goldEmber = createEmberSprite(true);

      function addEmber(initial) {
        var life = 105 + Math.random() * 70;
        embers.push({
          x: Math.random() * emberCanvas.width,
          y:
            emberCanvas.height *
            (initial
              ? 0.18 + Math.random() * 0.76
              : 0.55 + Math.random() * 0.45),
          vx: (Math.random() - 0.5) * 0.34,
          vy: 0.32 + Math.random() * 0.44,
          scale: 0.48 + Math.random() * 0.34,
          life: life,
          maxLife: life,
          gold: Math.random() > 0.72,
        });
      }

      function resizeEmbers() {
        emberCanvas.width = window.innerWidth;
        emberCanvas.height = window.innerHeight;
      }

      function animateEmbers() {
        if (document.body.classList.contains("reduced-motion")) {
          embers.length = 0;
          emberContext.clearRect(0, 0, emberCanvas.width, emberCanvas.height);
          setTimeout(animateEmbers, 500);
          return;
        }

        var now = Date.now();
        if (now >= nextEmber && embers.length < 26) {
          addEmber(false);
          nextEmber = now + 260 + Math.random() * 280;
        }

        emberContext.clearRect(0, 0, emberCanvas.width, emberCanvas.height);
        for (var i = embers.length - 1; i >= 0; i--) {
          var ember = embers[i];
          ember.x += ember.vx;
          ember.y -= ember.vy;
          ember.life--;
          if (ember.life <= 0) {
            embers.splice(i, 1);
            continue;
          }
          var alpha = Math.min(0.76, (ember.life / ember.maxLife) * 0.76);
          emberContext.save();
          emberContext.globalAlpha = alpha;
          emberContext.translate(ember.x, ember.y);
          emberContext.rotate(ember.vx * 0.7);
          emberContext.scale(ember.scale, ember.scale);
          emberContext.drawImage(ember.gold ? goldEmber : orangeEmber, -9, -16);
          emberContext.restore();
        }
        setTimeout(animateEmbers, 50);
      }

      resizeEmbers();
      for (var ei = 0; ei < 16; ei++) addEmber(true);
      window.addEventListener("resize", resizeEmbers);
      animateEmbers();
    }
  } catch (e) {
    if (emberCanvas) emberCanvas.style.display = "none";
  }

  var playerName = document.getElementById("playerName");
  var workshopId = document.getElementById("workshopId");
  var workshopStatus = document.getElementById("workshopStatus");
  var modsGrid = document.getElementById("modsGrid");
  var workshopDownloadBtn = document.getElementById("workshopDownloadBtn");
  var workshopProgress = document.getElementById("workshopProgress");
  var workshopProgressFill = document.getElementById("workshopProgressFill");
  var progressFooter = document.getElementById("progressFooter");
  var progressInfo = document.getElementById("progressInfo");
  var progressFill = document.getElementById("progressFill");
  var progressPercent = document.getElementById("progressPercent");
  var progressOpenFolder = document.getElementById("progressOpenFolder");
  var _workshopDownloadFolder = "";
  var manageInstallPopup = document.getElementById("manageInstallPopup");
  var launchOptionCards = document.querySelectorAll(
    "#launchDropdown .launch-option-card"
  );
  var modsPagination = document.getElementById("modsPagination");
  var modsPrevPageBtn = document.getElementById("modsPrevPageBtn");
  var modsNextPageBtn = document.getElementById("modsNextPageBtn");
  var modsPageLabel = document.getElementById("modsPageLabel");
  var librarySearchInput = document.getElementById("librarySearchInput");
  var librarySearchClearBtn = document.getElementById("librarySearchClearBtn");
  var libraryViewToggleBtn = document.getElementById("libraryViewToggleBtn");
  var libraryItemCount = document.getElementById("libraryItemCount");
  var workshopRefreshBtn = document.getElementById("workshopRefreshBtn");
  var modsItemsCache = [];
  var modsPage = 1;
  var modsPageSize = 12;
  var modsInitialized = false;
  var modsRefreshInFlight = false;
  var modsRefreshQueued = false;
  var libraryViewMode = "grid";
  try {
    if (localStorage.getItem("libraryViewMode") === "list")
      libraryViewMode = "list";
  } catch (e) {}

  var versionDropdown = document.getElementById("versionDropdown");
  var verDropDisplay = document.getElementById("verDropDisplay");
  var verDropText = document.getElementById("verDropText");
  var versionOptions = document.getElementById("versionOptions");
  var _versionsData = {};
  var _selectedVersion = "latest";
  var _latestVersionTag = "";

  var workshopBrowseGrid = document.getElementById("workshopBrowseGrid");
  var workshopViewToggleBtn = document.getElementById("workshopViewToggleBtn");
  var workshopSearchInput = document.getElementById("workshopSearchInput");
  var workshopSearchBtn = document.getElementById("workshopSearchBtn");
  var workshopBrowseRefreshBtn = document.getElementById(
    "workshopBrowseRefreshBtn"
  );
  var workshopBrowseClearBtn = document.getElementById(
    "workshopBrowseClearBtn"
  );
  var workshopBrowsePagination = document.getElementById(
    "workshopBrowsePagination"
  );
  var workshopBrowseItems = [];
  var workshopBrowseCurrentPage = 1;
  var workshopBrowseItemsPerPage = 10;
  var workshopBrowseLoading = false;
  var workshopBrowseMode = "browse";
  var workshopBrowseSearchTerm = "";
  var workshopBrowseError = "";
  var workshopBrowseSource = "none";
  var workshopBrowseCacheKey = "workshopBrowseCache";
  var workshopBrowseFetchedSort = "";
  var _workshopBrowsePollInterval = null;

  var workshopViewMode = "grid";
  try {
    if (localStorage.getItem("workshopViewMode") === "single") {
      workshopViewMode = "single";
    }
  } catch (e) {}

  function applyWorkshopViewMode() {
    var single = workshopViewMode === "single";
    if (workshopBrowseGrid) {
      if (single) workshopBrowseGrid.classList.add("single-column");
      else workshopBrowseGrid.classList.remove("single-column");
    }
    if (workshopViewToggleBtn) {
      workshopViewToggleBtn.textContent = single
        ? "Two columns"
        : "Single column";
      workshopViewToggleBtn.setAttribute(
        "aria-pressed",
        single ? "true" : "false"
      );
    }
  }

  if (workshopViewToggleBtn) {
    workshopViewToggleBtn.onclick = function () {
      workshopViewMode = workshopViewMode === "single" ? "grid" : "single";
      try {
        localStorage.setItem("workshopViewMode", workshopViewMode);
      } catch (e) {}
      applyWorkshopViewMode();
    };
  }
  applyWorkshopViewMode();

  var workshopOverlay = document.getElementById("workshopOverlay");
  var workshopModal = document.getElementById("workshopModal");
  var workshopModalTitle = document.getElementById("workshopModalTitle");
  var workshopModalClose = document.getElementById("workshopModalClose");
  var workshopModalImage = document.getElementById("workshopModalImage");
  var workshopModalInfo = document.getElementById("workshopModalInfo");
  var workshopModalDescription = document.getElementById(
    "workshopModalDescription"
  );
  var workshopModalViewBtn = document.getElementById("workshopModalViewBtn");
  var workshopModalDownloadBtn = document.getElementById(
    "workshopModalDownloadBtn"
  );
  var workshopFilterSelect = document.getElementById("workshopFilterSelect");
  var workshopTypeSelect = document.getElementById("workshopTypeSelect");
  var workshopModeSelect = document.getElementById("workshopModeSelect");

  var libraryOverlay = document.getElementById("libraryOverlay");
  var libraryModal = document.getElementById("libraryModal");
  var libraryModalTitle = document.getElementById("libraryModalTitle");
  var libraryModalClose = document.getElementById("libraryModalClose");
  var libraryModalImage = document.getElementById("libraryModalImage");
  var libraryModalInfo = document.getElementById("libraryModalInfo");
  var libraryModalDescription = document.getElementById(
    "libraryModalDescription"
  );
  var libraryModalViewBtn = document.getElementById("libraryModalViewBtn");
  var libraryModalOpenBtn = document.getElementById("libraryModalOpenBtn");

  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      if (this == null)
        throw new TypeError("Array.prototype.find called on null or undefined");
      if (typeof predicate !== "function")
        throw new TypeError(predicate + " is not a function");
      var list = Object(this);
      var length = parseInt(list.length, 10) || 0;
      var thisArg = arguments.length > 1 ? arguments[1] : void undefined;
      for (var i = 0; i < length; i++) {
        if (predicate.call(thisArg, list[i], i, list)) return list[i];
      }
      return undefined;
    };
  }

  if (window.Element && !Element.prototype.closest) {
    Element.prototype.closest = function (selector) {
      var el = this;
      while (el && el.nodeType === 1) {
        if (el.matches && el.matches(selector)) return el;
        if (el.msMatchesSelector && el.msMatchesSelector(selector)) return el;
        el = el.parentElement;
      }
      return null;
    };
  }

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function fixMojibake(str) {
    if (!str) return "";
    // Detect mojibake: UTF-8 bytes misinterpreted as Latin-1/Windows-1252
    // Common pattern: multi-byte sequences like Ã¢, Ã©, â˜…, â™¦ etc.
    if (
      /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/.test(
        str
      )
    ) {
      try {
        var decoded = decodeURIComponent(escape(str));
        return decoded;
      } catch (e) {}
    }
    return str;
  }

  function convertBBCodeToHtml(str) {
    if (!str) return "";
    var s = escapeHtml(fixMojibake(str));
    // Headings
    s = s.replace(/\[h1\](.*?)\[\/h1\]/gi, '<h3 class="bb-h1">$1</h3>');
    s = s.replace(/\[h2\](.*?)\[\/h2\]/gi, '<h4 class="bb-h2">$1</h4>');
    s = s.replace(/\[h3\](.*?)\[\/h3\]/gi, '<h5 class="bb-h3">$1</h5>');
    // Inline formatting
    s = s.replace(/\[b\]([\s\S]*?)\[\/b\]/gi, "<strong>$1</strong>");
    s = s.replace(/\[u\]([\s\S]*?)\[\/u\]/gi, "<u>$1</u>");
    s = s.replace(/\[i\]([\s\S]*?)\[\/i\]/gi, "<em>$1</em>");
    s = s.replace(/\[strike\]([\s\S]*?)\[\/strike\]/gi, "<s>$1</s>");
    s = s.replace(
      /\[code\]([\s\S]*?)\[\/code\]/gi,
      '<code class="bb-code">$1</code>'
    );
    // Links
    s = s.replace(
      /\[url=(.*?)\]([\s\S]*?)\[\/url\]/gi,
      '<a href="$1" class="bb-link" onclick="try{window.getExternal().openUrl(this.href)}catch(e){};return false;">$2</a>'
    );
    s = s.replace(
      /\[url\](.*?)\[\/url\]/gi,
      '<a href="$1" class="bb-link" onclick="try{window.getExternal().openUrl(this.href)}catch(e){};return false;">$1</a>'
    );
    // Images
    s = s.replace(
      /\[img\](.*?)\[\/img\]/gi,
      '<img src="$1" class="bb-img" onerror="this.style.display=\'none\'">'
    );
    // Lists
    s = s.replace(/\[list\]/gi, '<ul class="bb-list">');
    s = s.replace(/\[\/list\]/gi, "</ul>");
    s = s.replace(/\[\*\]/gi, "<li>");
    // Misc
    s = s.replace(/\[hr\]/gi, '<hr class="bb-hr">');
    s = s.replace(
      /\[spoiler\]([\s\S]*?)\[\/spoiler\]/gi,
      '<span class="bb-spoiler">$1</span>'
    );
    s = s.replace(/\[noparse\]([\s\S]*?)\[\/noparse\]/gi, "$1");
    s = s.replace(
      /\[previewyoutube=(\w+)[^\]]*\][\s\S]*?\[\/previewyoutube\]/gi,
      '<a href="https://youtube.com/watch?v=$1" class="bb-link" onclick="try{window.getExternal().openUrl(this.href)}catch(e){};return false;">[YouTube Video]</a>'
    );
    // Color & size tags
    s = s.replace(
      /\[color=(#?[a-zA-Z0-9]+)\]([\s\S]*?)\[\/color\]/gi,
      '<span style="color:$1;">$2</span>'
    );
    s = s.replace(/\[size=(\d+)\]([\s\S]*?)\[\/size\]/gi, "");
    // Table tags (Steam workshop uses these sometimes)
    s = s.replace(/\[table\]/gi, '<table class="bb-table">');
    s = s.replace(/\[\/table\]/gi, "</table>");
    s = s.replace(/\[tr\]/gi, "<tr>");
    s = s.replace(/\[\/tr\]/gi, "</tr>");
    s = s.replace(/\[td\]/gi, "<td>");
    s = s.replace(/\[\/td\]/gi, "</td>");
    s = s.replace(/\[th\]/gi, "<th>");
    s = s.replace(/\[\/th\]/gi, "</th>");
    // Quote
    s = s.replace(
      /\[quote(?:=[^\]]*)?\]([\s\S]*?)\[\/quote\]/gi,
      '<blockquote class="bb-quote">$1</blockquote>'
    );
    // Strip any remaining unknown BBCode tags
    s = s.replace(
      /\[\/?(?:olist|expand|previewyoutube|sharedfile|workshop)[^\]]*\]/gi,
      ""
    );
    // Newlines
    s = s.replace(/\r?\n/g, "<br>");
    return s;
  }

  function stripBBCode(str) {
    if (!str) return "";
    return fixMojibake(str)
      .replace(/\[\/?[^\]]+\]/g, "")
      .replace(/\s+/g, " ")
      .replace(/^\s+|\s+$/g, "");
  }

  function saveWorkshopCache(items) {
    try {
      localStorage.setItem(
        workshopBrowseCacheKey,
        JSON.stringify({ timestamp: Date.now(), items: items })
      );
    } catch (e) {}
  }

  function loadWorkshopCache() {
    try {
      var cached = localStorage.getItem(workshopBrowseCacheKey);
      if (!cached) return null;
      var data = JSON.parse(cached);
      return data.items || null;
    } catch (e) {
      return null;
    }
  }

  var externalBridge = null;
  function getExternal() {
    if (externalBridge) return externalBridge;
    try {
      if (
        window.chrome &&
        window.chrome.webview &&
        window.chrome.webview.hostObjects
      ) {
        var rawBridge = window.chrome.webview.hostObjects.sync.external;
        externalBridge = new Proxy(
          {},
          {
            get: function (_, name) {
              return function () {
                var args = [];
                for (var i = 0; i < arguments.length; i++)
                  args.push(arguments[i]);
                rawBridge.__request = JSON.stringify({
                  name: String(name),
                  args: args,
                });
                return rawBridge.__response;
              };
            },
          }
        );
        return externalBridge;
      }
    } catch (e) {}
    try {
      if (window.external) {
        externalBridge = window.external;
        return externalBridge;
      }
    } catch (e) {
      return null;
    }
    return null;
  }
  window.getExternal = getExternal;

  var gearBtn = document.getElementById("gearBtn");
  var launchDropdown = document.getElementById("launchDropdown");

  function setLaunchDropdownOpen(open) {
    if (!gearBtn || !launchDropdown) return;
    launchDropdown.classList.toggle("open", open);
    gearBtn.classList.toggle("open", open);
    gearBtn.setAttribute("aria-expanded", open ? "true" : "false");
  }

  if (gearBtn && launchDropdown) {
    gearBtn.onclick = function (e) {
      e.stopPropagation();
      setLaunchDropdownOpen(!launchDropdown.classList.contains("open"));
    };
    launchDropdown.onclick = function (e) {
      e.stopPropagation();
    };
  }

  document.addEventListener("click", function () {
    if (launchDropdown && launchDropdown.classList.contains("open")) {
      setLaunchDropdownOpen(false);
    }
  });

  document.addEventListener("keydown", function (e) {
    if (
      e.key === "Escape" &&
      launchDropdown &&
      launchDropdown.classList.contains("open")
    ) {
      setLaunchDropdownOpen(false);
      gearBtn.focus();
    }
  });

  try {
    var ver =
      getExternal() && getExternal().getVersion && getExternal().getVersion();
    if (ver) {
      var vd = document.getElementById("versionDisplay");
      if (vd) vd.textContent = "v" + ver;
      var sv = document.getElementById("settingsVersion");
      if (sv) sv.textContent = "v" + ver;
    }
  } catch (e) {}

  try {
    var stored =
      getExternal() &&
      getExternal().readPlayerName &&
      getExternal().readPlayerName();
    if (stored && playerName) playerName.value = stored;
  } catch (e) {}

  try {
    var storedOpts = null;
    try {
      var exOpts = getExternal();
      if (exOpts && exOpts.readLaunchOptions)
        storedOpts = exOpts.readLaunchOptions();
    } catch (e) {}
    if (storedOpts === null || storedOpts === undefined) {
      try {
        storedOpts = localStorage.getItem("boiii_launch_options");
      } catch (e) {}
    }
    if (storedOpts !== null && storedOpts !== undefined) {
      var rawParts = (storedOpts || "").split(" ");
      var parts = [];
      for (var pi = 0; pi < rawParts.length; pi++) {
        var trimmed = (rawParts[pi] || "")
          .toLowerCase()
          .replace(/^\s+|\s+$/g, "");
        if (trimmed) parts.push(trimmed);
      }
      for (var i = 0; i < launchOptionCards.length; i++) {
        var optVal = (
          launchOptionCards[i].getAttribute("data-option") || ""
        ).toLowerCase();
        var legacyOptVal = (
          launchOptionCards[i].getAttribute("data-option-legacy") || ""
        ).toLowerCase();
        for (var j = 0; j < parts.length; j++) {
          if (optVal && (optVal === parts[j] || legacyOptVal === parts[j])) {
            launchOptionCards[i].classList.add("active");
            break;
          }
        }
      }
    }
  } catch (e) {}

  try {
    var ex0 = getExternal();
    if (ex0 && ex0.getGamePath) {
      var gp = ex0.getGamePath();
      if (gp) {
        var cpd = document.getElementById("currentPathDisplay");
        if (cpd) cpd.textContent = gp;
        var spd = document.getElementById("settingsPathDisplay");
        if (spd) spd.textContent = gp;
      }
    }
  } catch (e) {}

  window.getPlayerName = function () {
    if (!playerName) return "";
    return (playerName.value || "").replace(/^\s+|\s+$/g, "");
  };

  (function () {
    var saveTimer = null;
    function saveName() {
      var name = (playerName.value || "").replace(/^\s+|\s+$/g, "");
      if (name) {
        try {
          getExternal().savePlayerName(name);
        } catch (e) {}
      }
    }
    if (playerName) {
      playerName.addEventListener("input", function () {
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(saveName, 500);
      });
      playerName.addEventListener("blur", function () {
        if (saveTimer) {
          clearTimeout(saveTimer);
          saveTimer = null;
        }
        saveName();
      });
    }
  })();

  window.getSelectedLaunchOption = function () {
    var selected = [];
    for (var i = 0; i < launchOptionCards.length; i++) {
      if (launchOptionCards[i].classList.contains("active")) {
        var opt = launchOptionCards[i].getAttribute("data-option") || "";
        if (opt) selected.push(opt);
      }
    }
    return selected.join(" ");
  };

  for (var oi = 0; oi < launchOptionCards.length; oi++) {
    (function (card) {
      card.onclick = function (e) {
        e.stopPropagation();
        card.classList.toggle("active");
        try {
          localStorage.setItem(
            "boiii_launch_options",
            window.getSelectedLaunchOption()
          );
          var ex = getExternal();
          if (ex && ex.saveLaunchOptions)
            ex.saveLaunchOptions(window.getSelectedLaunchOption());
        } catch (e2) {}
      };
    })(launchOptionCards[oi]);
  }

  var navBtns = document.querySelectorAll(".nav-btn");
  var pages = document.querySelectorAll(".page");
  var activePage = "main";
  function setPage(targetPage) {
    activePage = targetPage;
    for (var j = 0; j < navBtns.length; j++) {
      navBtns[j].classList.remove("active");
      if (navBtns[j].getAttribute("data-page") === targetPage)
        navBtns[j].classList.add("active");
    }
    for (var k = 0; k < pages.length; k++) {
      pages[k].classList.remove("active");
    }
    var targetEl = document.getElementById(targetPage + "Page");
    if (targetEl) targetEl.classList.add("active");

    if (targetPage === "library") {
      if (!modsInitialized) refreshModsGrid();
    }

    if (
      targetPage === "workshop" &&
      workshopBrowseItems.length === 0 &&
      !workshopBrowseLoading
    ) {
      try {
        var exP = getExternal();
        if (exP && exP.workshopGetBrowseState) {
          var stateJson = exP.workshopGetBrowseState();
          if (stateJson) {
            var state =
              typeof stateJson === "string" ? JSON.parse(stateJson) : stateJson;
            if (state && Array.isArray(state.items) && state.items.length > 0) {
              workshopBrowseItems = state.items;
              workshopBrowseMode = state.mode || "browse";
              workshopBrowseSearchTerm =
                workshopBrowseMode === "search" ? state.query || "" : "";
              workshopBrowseError = state.error || "";
              renderWorkshopBrowse();
            }
          }
        }
      } catch (e) {}
      loadWorkshopBrowse(1);
    }
  }

  for (var ni = 0; ni < navBtns.length; ni++) {
    (function (btn) {
      btn.onclick = function () {
        setPage(btn.getAttribute("data-page"));
      };
    })(navBtns[ni]);
  }

  var navLogo = document.querySelector(".nav-logo");
  if (navLogo) {
    navLogo.onclick = function () {
      setPage("main");
    };
  }

  function formatSize(bytes) {
    if (bytes > 1073741824) return (bytes / 1073741824).toFixed(2) + " GB";
    if (bytes > 1048576) return (bytes / 1048576).toFixed(1) + " MB";
    if (bytes > 1024) return (bytes / 1024).toFixed(0) + " KB";
    return bytes + " B";
  }

  function lookupMissingSizes(items, onResult) {
    var ex = getExternal();
    if (!ex || !ex.workshopGetSize) return;
    var pending = [];
    for (var i = 0; i < items.length; i++) {
      if (!(parseInt(items[i].file_size, 10) > 0)) pending.push(items[i]);
    }
    var tries = 0;
    function poll() {
      var still = [];
      for (var j = 0; j < pending.length; j++) {
        var result = "";
        try {
          result = String(ex.workshopGetSize(String(pending[j].id)) || "");
        } catch (e) {}
        if (result === "") {
          still.push(pending[j]);
        } else {
          pending[j].file_size = parseInt(result, 10) || 0;
          onResult(pending[j]);
        }
      }
      pending = still;
      if (pending.length === 0) return;
      if (++tries < 30) {
        setTimeout(poll, 700);
      } else {
        for (var k = 0; k < pending.length; k++) onResult(pending[k]);
      }
    }
    if (pending.length > 0) poll();
  }

  function showMessage(title, body) {
    var pop = document.getElementById("messagePopup");
    if (!pop) return;
    var t = document.getElementById("messagePopupTitle");
    var b = document.getElementById("messagePopupBody");
    if (t) t.textContent = title || "Message";
    if (b) b.textContent = body || "";
    pop.classList.add("active");
  }

  function showConfirm(title, body, onConfirm, confirmLabel) {
    var popup = document.getElementById("confirmPopup");
    if (!popup) return;
    var t = document.getElementById("confirmPopupTitle");
    var b = document.getElementById("confirmPopupBody");
    if (t) t.textContent = title || "Confirm";
    if (b) b.innerHTML = body || "";
    document.getElementById("confirmPopupConfirm").textContent =
      confirmLabel || "Confirm";
    popup.classList.add("active");
    var done = false;
    function close() {
      if (done) return;
      done = true;
      popup.classList.remove("active");
    }
    document.getElementById("confirmPopupCancel").onclick = function () {
      close();
    };
    document.getElementById("confirmPopupConfirm").onclick = function () {
      close();
      if (typeof onConfirm === "function") onConfirm();
    };
    var cClose = popup.querySelector(".popup-close");
    if (cClose) cClose.onclick = close;
    popup.onclick = function (e) {
      if (e.target === popup) close();
    };
  }

  function hideMessagePopup() {
    var pop = document.getElementById("messagePopup");
    if (pop) pop.classList.remove("active");
  }

  document.getElementById("messagePopupOk").onclick = hideMessagePopup;
  document.getElementById("messagePopup").onclick = function (e) {
    if (e.target === document.getElementById("messagePopup"))
      hideMessagePopup();
  };
  var msgClose = document.querySelector("#messagePopup .popup-close");
  if (msgClose) msgClose.onclick = hideMessagePopup;

  function showProgress(message, percent, details) {
    var text = message || "";
    if (details) text += " \u2014 " + details;
    progressInfo.textContent = text;
    var pf = document.getElementById("progressFill");
    if (percent <= 0) {
      if (pf && !pf.classList.contains("indeterminate"))
        pf.classList.add("indeterminate");
      progressPercent.textContent = "";
    } else {
      if (pf && pf.classList.contains("indeterminate")) {
        pf.classList.remove("indeterminate");
        pf.style.transform = "";
      }
      progressFill.style.width = percent + "%";
      progressPercent.textContent = percent.toFixed(1) + "%";
    }
    progressFooter.classList.add("active");
  }

  function hideProgress() {
    progressFooter.classList.remove("active");
  }

  function cancelWorkshopPoll() {
    if (_workshopBrowsePollInterval) {
      clearInterval(_workshopBrowsePollInterval);
      _workshopBrowsePollInterval = null;
    }
    workshopBrowseLoading = false;
  }

  function getWorkshopBrowseState() {
    try {
      var ex = getExternal();
      if (!ex || !ex.workshopGetBrowseState) return null;
      var stateJson = ex.workshopGetBrowseState();
      if (!stateJson) return null;
      var state =
        typeof stateJson === "string" ? JSON.parse(stateJson) : stateJson;
      if (!state || !Array.isArray(state.items)) return null;
      return state;
    } catch (e) {
      return null;
    }
  }

  function syncWorkshopBrowseState(state) {
    if (!state) return;
    workshopBrowseLoading = !!state.loading;
    workshopBrowseMode = state.mode || "browse";
    workshopBrowseSearchTerm =
      workshopBrowseMode === "search" ? state.query || "" : "";
    workshopBrowseError = state.error || "";
    workshopBrowseSource = state.source || "none";
    workshopBrowseItems = Array.isArray(state.items) ? state.items : [];
  }

  function workshopBrowseSort() {
    var sort = workshopFilterSelect ? workshopFilterSelect.value : "";
    return sort === "mostsubs" || sort === "trendweek" ? sort : "mostrecent";
  }

  function loadWorkshopBrowse(page) {
    cancelWorkshopPoll();
    if (workshopBrowseFetchedSort !== workshopBrowseSort()) {
      workshopBrowseItems = [];
    }
    workshopBrowseFetchedSort = workshopBrowseSort();
    workshopBrowseLoading = true;
    workshopBrowseMode = "browse";
    workshopBrowseError = "";
    workshopBrowseSource = "none";
    workshopBrowseCurrentPage = page || 1;
    workshopBrowseSearchTerm = "";
    if (workshopBrowseItems.length === 0) showWorkshopLoading();
    try {
      var ex = getExternal();
      if (ex && ex.workshopBrowse) {
        ex.workshopBrowse(workshopBrowseCurrentPage, workshopBrowseFetchedSort);
        pollWorkshopBrowseResults();
      } else {
        workshopBrowseLoading = false;
        showWorkshopEmpty("Workshop browsing is not available.");
      }
    } catch (e) {
      workshopBrowseLoading = false;
      showWorkshopEmpty("Workshop browsing failed to start.");
    }
  }

  function loadWorkshopSearch(query) {
    if (!query || !query.replace(/^\s+|\s+$/g, "")) return;
    var normalizedQuery = query.replace(/^\s+|\s+$/g, "");
    cancelWorkshopPoll();
    workshopBrowseLoading = true;
    workshopBrowseMode = "search";
    workshopBrowseError = "";
    workshopBrowseSource = "none";
    workshopBrowseSearchTerm = normalizedQuery;
    workshopBrowseCurrentPage = 1;
    showWorkshopLoading();
    try {
      var ex = getExternal();
      if (ex && ex.workshopSearch) {
        ex.workshopSearch(normalizedQuery);
        pollWorkshopBrowseResults();
      } else {
        workshopBrowseLoading = false;
        showWorkshopEmpty("Workshop search is not available.");
      }
    } catch (e) {
      workshopBrowseLoading = false;
      showWorkshopEmpty("Workshop search failed to start.");
    }
  }

  function pollWorkshopBrowseResults() {
    if (_workshopBrowsePollInterval) {
      clearInterval(_workshopBrowsePollInterval);
      _workshopBrowsePollInterval = null;
    }
    var pollCount = 0;
    var maxPolls = 400;
    var lastRenderKey = "";

    var pollInterval = setInterval(function () {
      pollCount++;
      _workshopBrowsePollInterval = pollInterval;

      var state = getWorkshopBrowseState();
      if (state) {
        syncWorkshopBrowseState(state);

        var renderKey = [
          state.requestToken || 0,
          workshopBrowseLoading ? 1 : 0,
          workshopBrowseMode,
          workshopBrowseSearchTerm,
          workshopBrowseSource,
          workshopBrowseError,
          workshopBrowseItems.length,
        ].join("|");

        if (renderKey !== lastRenderKey) {
          lastRenderKey = renderKey;
          if (workshopBrowseItems.length > 0 || !workshopBrowseLoading) {
            renderWorkshopBrowse();
          }
        }

        if (!workshopBrowseLoading) {
          clearInterval(pollInterval);
          _workshopBrowsePollInterval = null;
          renderWorkshopBrowse();
          return;
        }
      }

      if (pollCount > maxPolls) {
        clearInterval(pollInterval);
        _workshopBrowsePollInterval = null;
        workshopBrowseLoading = false;
        workshopBrowseError = "Loading workshop items took too long.";
        if (workshopBrowseItems.length > 0) renderWorkshopBrowse();
        else showWorkshopEmpty(workshopBrowseError);
      }
    }, 100);

    _workshopBrowsePollInterval = pollInterval;
  }

  function showWorkshopLoading() {
    if (workshopBrowsePagination)
      workshopBrowsePagination.style.display = "none";
    workshopBrowseGrid.innerHTML =
      '<div class="workshop-loading"><div class="loading-spinner"></div><span>Loading workshop items...</span></div>';
  }

  function showWorkshopEmpty(message) {
    workshopBrowseGrid.innerHTML =
      '<div class="workshop-browse-empty"><div class="workshop-browse-empty-icon">\u2715</div><div>' +
      escapeHtml(message || "No items found") +
      "</div></div>";
    if (workshopBrowsePagination)
      workshopBrowsePagination.style.display = "none";
  }

  function showErrorOrCache(errorMessage) {
    workshopBrowseError = errorMessage || "";
    if (workshopBrowseItems.length > 0) renderWorkshopBrowse();
    else showWorkshopEmpty(workshopBrowseError);
  }

  function renderWorkshopBrowse() {
    workshopBrowseGrid.innerHTML = "";
    var nonArchive = [];
    for (var ai = 0; ai < workshopBrowseItems.length; ai++) {
      var item = workshopBrowseItems[ai];
      if (
        item.title &&
        (item.title.indexOf("**ARCHIVE**") !== -1 ||
          item.title.indexOf("ARCHIVE") === 0)
      )
        continue;
      if (
        item.description &&
        item.description.indexOf("THIS MAP IS AN ARCHIVE") !== -1
      )
        continue;
      nonArchive.push(item);
    }

    var filteredItems = nonArchive;
    if (
      workshopBrowseMode !== "search" &&
      workshopBrowseSearchTerm.length > 0
    ) {
      var term = workshopBrowseSearchTerm
        .toLowerCase()
        .replace(/^\s+|\s+$/g, "");
      var searched = [];
      for (var si = 0; si < nonArchive.length; si++) {
        var it = nonArchive[si];
        var titleMatch =
          it.title && it.title.toLowerCase().indexOf(term) !== -1;
        var descMatch =
          it.description && it.description.toLowerCase().indexOf(term) !== -1;
        var idMatch = it.id && String(it.id).toLowerCase().indexOf(term) !== -1;
        if (titleMatch || descMatch || idMatch) searched.push(it);
      }
      filteredItems = searched;
    }

    var typeFilter = workshopTypeSelect ? workshopTypeSelect.value : "";
    var modeFilter = workshopModeSelect ? workshopModeSelect.value : "";
    if (typeFilter || modeFilter) {
      filteredItems = filteredItems.filter(function (item) {
        var tags = item.tags || [];
        return (
          (!typeFilter || tags.indexOf(typeFilter) !== -1) &&
          (!modeFilter || tags.indexOf(modeFilter) !== -1)
        );
      });
    }

    var sortMode = workshopFilterSelect
      ? workshopFilterSelect.value
      : "mostrecent";
    if (sortMode === "mostsubs") {
      filteredItems = filteredItems.slice(0).sort(function (a, b) {
        return (parseInt(b.subs, 10) || 0) - (parseInt(a.subs, 10) || 0);
      });
    } else if (sortMode === "trend") {
      filteredItems = filteredItems.slice(0).sort(function (a, b) {
        var rA = parseInt(a.starRating, 10) || 0;
        var rB = parseInt(b.starRating, 10) || 0;
        if (rB !== rA) return rB - rA;
        return (parseInt(b.subs, 10) || 0) - (parseInt(a.subs, 10) || 0);
      });
    } else if (sortMode === "oldest") {
      filteredItems = filteredItems.slice(0).reverse();
    } else if (sortMode === "alphabetical") {
      filteredItems = filteredItems.slice(0).sort(function (a, b) {
        var ta = (a.title || "").toLowerCase();
        var tb = (b.title || "").toLowerCase();
        return ta < tb ? -1 : ta > tb ? 1 : 0;
      });
    }

    if (!filteredItems || filteredItems.length === 0) {
      if (workshopBrowseError) {
        showWorkshopEmpty(workshopBrowseError);
        return;
      }
      showWorkshopEmpty(
        workshopBrowseMode === "search"
          ? "No items match your search"
          : "No workshop items available"
      );
      return;
    }

    var totalPages =
      Math.ceil(filteredItems.length / workshopBrowseItemsPerPage) || 1;
    if (workshopBrowseCurrentPage < 1) workshopBrowseCurrentPage = 1;
    if (workshopBrowseCurrentPage > totalPages)
      workshopBrowseCurrentPage = totalPages;

    var start = (workshopBrowseCurrentPage - 1) * workshopBrowseItemsPerPage;
    var end = Math.min(
      start + workshopBrowseItemsPerPage,
      filteredItems.length
    );

    for (var i = start; i < end; i++) {
      var it = filteredItems[i];
      var card = document.createElement("div");
      card.className = "workshop-item-card";

      var imageHtml = it.imageUrl
        ? '<div class="workshop-item-image"><img src="' +
          escapeHtml(it.imageUrl) +
          '" alt="" loading="lazy" decoding="async"></div>'
        : '<div class="workshop-item-image"><div class="no-image">No Image</div></div>';

      var rawDesc = stripBBCode(
        (it.description || "").replace(/[\r\n]+/g, " ")
      );
      var desc = rawDesc.substring(0, 90);
      if (rawDesc.length > 90) desc += "...";

      var ratingHtml = "";
      var sr = parseInt(it.starRating, 10) || 0;
      if (sr > 0) {
        var starStr = "";
        for (var s = 0; s < sr; s++) starStr += "\u2605";
        for (var s = sr; s < 5; s++) starStr += "\u2606";
        var rColor =
          sr >= 4
            ? "rgba(34,197,94,0.8)"
            : sr >= 3
              ? "rgba(250,204,21,0.8)"
              : "rgba(239,68,68,0.8)";
        ratingHtml =
          '<span style="font-size:0.72rem;color:' +
          rColor +
          ';margin-left:7px;">' +
          starStr +
          "</span>";
      }

      var fSize = parseInt(it.file_size, 10) || 0;
      var fStr = fSize > 0 ? formatSize(fSize) : "";
      var installed = findLibraryItem(it.id);
      var buttonLabel = installed
        ? installed.needsUpdate
          ? "Update"
          : "Installed"
        : "Download";

      var contentHtml =
        '<div class="workshop-item-content">' +
        '<div class="workshop-item-main">' +
        '<div class="workshop-item-title">' +
        escapeHtml(it.title || "Untitled") +
        ratingHtml +
        "</div>" +
        (desc
          ? '<div class="workshop-item-description">' +
            escapeHtml(desc) +
            "</div>"
          : "") +
        '<div class="workshop-item-id">ID: ' +
        escapeHtml(it.id) +
        "</div>" +
        "</div>" +
        '<div class="workshop-item-actions">' +
        '<span class="workshop-item-size" data-size-id="' +
        escapeHtml(it.id) +
        '">' +
        fStr +
        "</span>" +
        '<button type="button" class="workshop-item-button' +
        (installed && !installed.needsUpdate ? " installed" : "") +
        '" data-workshop-id="' +
        escapeHtml(it.id) +
        '">' +
        buttonLabel +
        "</button>" +
        "</div>" +
        "</div>";

      card.innerHTML = imageHtml + contentHtml;

      var cardImg = card.querySelector("img");
      if (cardImg) {
        (function (img) {
          img.onerror = function () {
            this.onerror = null;
            this.parentNode.innerHTML = '<div class="no-image">No Image</div>';
          };
        })(cardImg);
      }

      workshopBrowseGrid.appendChild(card);
    }

    lookupMissingSizes(filteredItems.slice(start, end), function (item) {
      var label = workshopBrowseGrid.querySelector(
        '[data-size-id="' + item.id + '"]'
      );
      if (label && parseInt(item.file_size, 10) > 0)
        label.textContent = formatSize(item.file_size);
    });

    if (workshopBrowsePagination) {
      if (totalPages > 1) {
        workshopBrowsePagination.style.display = "flex";
        workshopBrowsePagination.innerHTML = "";

        var prevBtn = document.createElement("button");
        prevBtn.type = "button";
        prevBtn.className = "btn";
        prevBtn.textContent = "\u2039 Prev";
        prevBtn.disabled = workshopBrowseCurrentPage <= 1;
        prevBtn.onclick = function () {
          if (workshopBrowseCurrentPage > 1) {
            workshopBrowseCurrentPage--;
            renderWorkshopBrowse();
            workshopBrowseGrid.scrollIntoView();
          }
        };
        workshopBrowsePagination.appendChild(prevBtn);

        var pages2 = [];
        if (totalPages <= 7) {
          for (var p = 1; p <= totalPages; p++) pages2.push(p);
        } else {
          pages2.push(1);
          if (workshopBrowseCurrentPage > 4) pages2.push("...");
          var rangeStart = Math.max(2, workshopBrowseCurrentPage - 2);
          var rangeEnd = Math.min(
            totalPages - 1,
            workshopBrowseCurrentPage + 2
          );
          if (workshopBrowseCurrentPage <= 4)
            rangeEnd = Math.min(totalPages - 1, 5);
          if (workshopBrowseCurrentPage >= totalPages - 3)
            rangeStart = Math.max(2, totalPages - 4);
          for (var p = rangeStart; p <= rangeEnd; p++) pages2.push(p);
          if (workshopBrowseCurrentPage < totalPages - 3) pages2.push("...");
          pages2.push(totalPages);
        }

        for (var pii = 0; pii < pages2.length; pii++) {
          if (pages2[pii] === "...") {
            var dots = document.createElement("span");
            dots.className = "page-ellipsis";
            dots.textContent = "...";
            workshopBrowsePagination.appendChild(dots);
          } else {
            var pageBtn = document.createElement("button");
            pageBtn.type = "button";
            pageBtn.className =
              "btn" +
              (pages2[pii] === workshopBrowseCurrentPage ? " page-active" : "");
            pageBtn.textContent = String(pages2[pii]);
            pageBtn.setAttribute("data-page", pages2[pii]);
            pageBtn.onclick = function () {
              var pg = parseInt(this.getAttribute("data-page"), 10);
              if (pg !== workshopBrowseCurrentPage) {
                workshopBrowseCurrentPage = pg;
                renderWorkshopBrowse();
                workshopBrowseGrid.scrollIntoView();
              }
            };
            workshopBrowsePagination.appendChild(pageBtn);
          }
        }

        var nextBtn = document.createElement("button");
        nextBtn.type = "button";
        nextBtn.className = "btn";
        nextBtn.textContent = "Next \u203A";
        nextBtn.disabled = workshopBrowseCurrentPage >= totalPages;
        nextBtn.onclick = function () {
          if (workshopBrowseCurrentPage < totalPages) {
            workshopBrowseCurrentPage++;
            renderWorkshopBrowse();
            workshopBrowseGrid.scrollIntoView();
          }
        };
        workshopBrowsePagination.appendChild(nextBtn);

        var info = document.createElement("span");
        info.className = "page-info";
        info.textContent = filteredItems.length + " items";
        workshopBrowsePagination.appendChild(info);
      } else {
        workshopBrowsePagination.style.display = "none";
      }
    }
  }

  function showWorkshopModal(item) {
    if (!item) return;
    workshopModalTitle.textContent = item.title || "Untitled";
    if (item.imageUrl) {
      workshopModalImage.innerHTML =
        '<img src="' + escapeHtml(item.imageUrl) + '" alt="">';
      var mImg = workshopModalImage.querySelector("img");
      if (mImg) {
        mImg.onerror = function () {
          this.onerror = null;
          workshopModalImage.innerHTML =
            '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:rgba(200,196,192,0.25);font-size:2rem;">No Image</div>';
        };
      }
    } else {
      workshopModalImage.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:rgba(200,196,192,0.25);font-size:2rem;">No Image</div>';
    }

    var modalRatingHtml =
      '<span style="color:rgba(200,196,192,0.5);">N/A</span>';
    var mSr = parseInt(item.starRating, 10) || 0;
    if (mSr > 0) {
      var mStars = "";
      for (var ms = 0; ms < mSr; ms++) mStars += "\u2605";
      for (var ms = mSr; ms < 5; ms++) mStars += "\u2606";
      var mColor =
        mSr >= 4
          ? "rgba(34,197,94,0.9)"
          : mSr >= 3
            ? "rgba(250,204,21,0.9)"
            : "rgba(239,68,68,0.9)";
      modalRatingHtml =
        '<span style="color:' +
        mColor +
        ';">' +
        mStars +
        " (" +
        mSr +
        "/5)</span>";
    } else {
      modalRatingHtml =
        '<span style="color:rgba(200,196,192,0.45);">Not enough ratings</span>';
    }

    var modalSubsHtml = "";
    var mSubs = parseInt(item.subs, 10) || 0;
    var mFavs = parseInt(item.favorites, 10) || 0;
    if (mSubs > 0 || mFavs > 0) {
      modalSubsHtml =
        '<div class="workshop-modal-info-item">' +
        '<div class="workshop-modal-info-label">Popularity</div>' +
        '<div class="workshop-modal-info-value">' +
        (mSubs > 0 ? mSubs.toLocaleString() + " subs" : "") +
        (mSubs > 0 && mFavs > 0 ? " \u00B7 " : "") +
        (mFavs > 0 ? mFavs.toLocaleString() + " favs" : "") +
        "</div></div>";
    }

    var mSize = parseInt(item.file_size, 10) || 0;
    var modalSizeHtml =
      '<div class="workshop-modal-info-item">' +
      '<div class="workshop-modal-info-label">Size</div>' +
      '<div class="workshop-modal-info-value" data-size-id="' +
      escapeHtml(item.id) +
      '">' +
      (mSize > 0 ? formatSize(mSize) : "Checking...") +
      "</div></div>";

    workshopModalInfo.innerHTML =
      '<div class="workshop-modal-info-item">' +
      '<div class="workshop-modal-info-label">Workshop ID</div>' +
      '<div class="workshop-modal-info-value" style="font-family:Consolas,monospace;">' +
      escapeHtml(item.id || "N/A") +
      "</div>" +
      "</div>" +
      '<div class="workshop-modal-info-item">' +
      '<div class="workshop-modal-info-label">Rating</div>' +
      '<div class="workshop-modal-info-value">' +
      modalRatingHtml +
      "</div>" +
      "</div>" +
      modalSubsHtml +
      modalSizeHtml;

    workshopModalDescription.innerHTML = convertBBCodeToHtml(
      item.description || "No description available."
    );
    workshopModalViewBtn.onclick = function () {
      try {
        getExternal().openUrl(
          "https://steamcommunity.com/sharedfiles/filedetails/?id=" + item.id
        );
      } catch (e) {}
    };
    workshopModalDownloadBtn.onclick = function () {
      hideWorkshopModal();
      startWorkshopDownload(item.id, item.title);
    };
    workshopOverlay.classList.add("active");
    workshopModal.classList.add("active");
    if (!(mSize > 0)) {
      lookupMissingSizes([item], function () {
        var label = workshopModalInfo.querySelector(
          '[data-size-id="' + item.id + '"]'
        );
        if (label)
          label.textContent =
            parseInt(item.file_size, 10) > 0
              ? formatSize(item.file_size)
              : "Unknown";
      });
    }
  }

  function hideWorkshopModal() {
    workshopOverlay.classList.remove("active");
    workshopModal.classList.remove("active");
  }

  if (workshopModalClose) workshopModalClose.onclick = hideWorkshopModal;
  if (workshopOverlay) workshopOverlay.onclick = hideWorkshopModal;
  if (workshopModal)
    workshopModal.onclick = function (e) {
      e.stopPropagation();
    };

  function showLibraryModModal(item) {
    if (!item) return;
    libraryModalTitle.textContent = item.name || item.folder || "Untitled";

    if (item.image && String(item.image).length > 0) {
      libraryModalImage.innerHTML =
        '<img src="' + escapeHtml(item.image) + '" alt="">';
      var mImg = libraryModalImage.querySelector("img");
      if (mImg) {
        mImg.onerror = function () {
          this.onerror = null;
          libraryModalImage.innerHTML =
            '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:rgba(200,196,192,0.25);font-size:2rem;">No Image</div>';
        };
      }
    } else {
      libraryModalImage.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:rgba(200,196,192,0.25);font-size:2rem;">No Image</div>';
    }

    var modalRatingHtml = "";
    var mSr = parseInt(item.starRating, 10) || 0;
    if (mSr > 0) {
      var mStars = "";
      for (var ms = 0; ms < mSr; ms++) mStars += "\u2605";
      for (var ms = mSr; ms < 5; ms++) mStars += "\u2606";
      var mColor =
        mSr >= 4
          ? "rgba(34,197,94,0.9)"
          : mSr >= 3
            ? "rgba(250,204,21,0.9)"
            : "rgba(239,68,68,0.9)";
      modalRatingHtml =
        '<div class="workshop-modal-info-item">' +
        '<div class="workshop-modal-info-label">Rating</div>' +
        '<div class="workshop-modal-info-value"><span style="color:' +
        mColor +
        ';">' +
        mStars +
        " (" +
        mSr +
        "/5)</span></div></div>";
    }

    var modalSubsHtml = "";
    var mSubs = parseInt(item.subs, 10) || 0;
    if (mSubs > 0) {
      modalSubsHtml =
        '<div class="workshop-modal-info-item">' +
        '<div class="workshop-modal-info-label">Subscribers</div>' +
        '<div class="workshop-modal-info-value">' +
        mSubs.toLocaleString() +
        "</div></div>";
    }

    var modalSizeHtml = "";
    var lSz = parseInt(item.localSize, 10) || 0;
    var aSz = parseInt(item.file_size, 10) || 0;
    var mSize = lSz > 0 ? lSz : aSz;
    if (mSize > 0) {
      var sStr = formatSize(mSize);
      modalSizeHtml =
        '<div class="workshop-modal-info-item">' +
        '<div class="workshop-modal-info-label">Size</div>' +
        '<div class="workshop-modal-info-value">' +
        sStr +
        "</div></div>";
    }

    var modalTypeHtml =
      '<div class="workshop-modal-info-item">' +
      '<div class="workshop-modal-info-label">Type</div>' +
      '<div class="workshop-modal-info-value">' +
      escapeHtml(
        (item.type || "mod") + (item.source === "steam" ? " (Steam)" : "")
      ) +
      "</div></div>";

    libraryModalInfo.innerHTML =
      (item.id
        ? '<div class="workshop-modal-info-item">' +
          '<div class="workshop-modal-info-label">Workshop ID</div>' +
          '<div class="workshop-modal-info-value" style="font-family:Consolas,monospace;">' +
          escapeHtml(String(item.id)) +
          "</div></div>"
        : "") +
      modalTypeHtml +
      modalRatingHtml +
      modalSubsHtml +
      modalSizeHtml;

    libraryModalDescription.innerHTML = convertBBCodeToHtml(
      item.description || "No description available."
    );

    if (item.id && String(item.id).length > 0) {
      libraryModalViewBtn.style.display = "";
      libraryModalViewBtn.onclick = function () {
        try {
          getExternal().openUrl(
            "https://steamcommunity.com/sharedfiles/filedetails/?id=" + item.id
          );
        } catch (e) {}
      };
    } else {
      libraryModalViewBtn.style.display = "none";
    }

    libraryModalOpenBtn.onclick = function () {
      if (item.path) {
        try {
          getExternal().openUrl(item.path);
        } catch (e) {}
      }
    };
    if (!item.path) libraryModalOpenBtn.style.display = "none";
    else libraryModalOpenBtn.style.display = "";

    libraryOverlay.classList.add("active");
    libraryModal.classList.add("active");
  }

  function hideLibraryModal() {
    libraryOverlay.classList.remove("active");
    libraryModal.classList.remove("active");
  }

  if (libraryModalClose) libraryModalClose.onclick = hideLibraryModal;
  if (libraryOverlay) libraryOverlay.onclick = hideLibraryModal;
  if (libraryModal)
    libraryModal.onclick = function (e) {
      e.stopPropagation();
    };

  [workshopFilterSelect, workshopTypeSelect, workshopModeSelect].forEach(
    function (select) {
      if (select)
        select.onchange = function () {
          workshopBrowseCurrentPage = 1;
          if (
            workshopBrowseMode === "browse" &&
            workshopBrowseFetchedSort !== workshopBrowseSort()
          ) {
            loadWorkshopBrowse(1);
            return;
          }
          renderWorkshopBrowse();
        };
    }
  );

  if (workshopSearchBtn) {
    workshopSearchBtn.onclick = function () {
      var st = workshopSearchInput
        ? workshopSearchInput.value.replace(/^\s+|\s+$/g, "")
        : "";
      if (!st) {
        workshopBrowseCurrentPage = 1;
        loadWorkshopBrowse(1);
        return;
      }
      loadWorkshopSearch(st);
    };
  }

  if (workshopSearchInput) {
    workshopSearchInput.onkeypress = function (e) {
      if (e.keyCode === 13 || e.key === "Enter") workshopSearchBtn.click();
    };
  }

  if (workshopBrowseRefreshBtn) {
    workshopBrowseRefreshBtn.onclick = function () {
      workshopBrowseSearchTerm = "";
      if (workshopSearchInput) workshopSearchInput.value = "";
      workshopBrowseCurrentPage = 1;
      loadWorkshopBrowse(1);
    };
  }

  if (workshopBrowseClearBtn) {
    workshopBrowseClearBtn.onclick = function () {
      workshopBrowseItems = [];
      workshopBrowseSearchTerm = "";
      workshopBrowseCurrentPage = 1;
      if (workshopSearchInput) workshopSearchInput.value = "";
      try {
        localStorage.removeItem(workshopBrowseCacheKey);
      } catch (e) {}
      loadWorkshopBrowse(1);
    };
  }

  workshopBrowseGrid.addEventListener("click", function (e) {
    var btn = e.target.closest
      ? e.target.closest(".workshop-item-button")
      : null;
    if (!btn) {
      var t = e.target;
      while (t && t !== workshopBrowseGrid) {
        if (t.className && t.className.indexOf("workshop-item-button") !== -1) {
          btn = t;
          break;
        }
        t = t.parentNode;
      }
    }
    if (btn) {
      var id = btn.getAttribute("data-workshop-id");
      if (id) {
        var foundItem = null;
        for (var fi = 0; fi < workshopBrowseItems.length; fi++) {
          if (workshopBrowseItems[fi].id === id) {
            foundItem = workshopBrowseItems[fi];
            break;
          }
        }
        startWorkshopDownload(id, foundItem ? foundItem.title : id);
      }
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    var card = e.target.closest
      ? e.target.closest(".workshop-item-card")
      : null;
    if (!card) {
      var t2 = e.target;
      while (t2 && t2 !== workshopBrowseGrid) {
        if (t2.className && t2.className.indexOf("workshop-item-card") !== -1) {
          card = t2;
          break;
        }
        t2 = t2.parentNode;
      }
    }
    if (card) {
      var cBtn = card.querySelector(".workshop-item-button");
      var cid = cBtn ? cBtn.getAttribute("data-workshop-id") : null;
      if (cid) {
        var found = null;
        for (var fi2 = 0; fi2 < workshopBrowseItems.length; fi2++) {
          if (workshopBrowseItems[fi2].id === cid) {
            found = workshopBrowseItems[fi2];
            break;
          }
        }
        if (found) showWorkshopModal(found);
      }
      e.preventDefault();
      e.stopPropagation();
    }
  });

  function stopWorkshopDownloadCompletely() {
    window._workshopCanceled = true;
    try {
      var ex = getExternal();
      if (ex && ex.workshopCancelDownload) ex.workshopCancelDownload();
    } catch (e) {}
    if (window._workshopPollInterval) {
      clearInterval(window._workshopPollInterval);
      window._workshopPollInterval = null;
    }
    window._workshopIsPaused = false;
    var pauseBtn = document.getElementById("workshopProgressPause");
    var pauseFooter = document.getElementById("progressPause");
    if (pauseBtn) {
      pauseBtn.innerHTML = "&#9208;";
      pauseBtn.title = "Pause";
    }
    if (pauseFooter) {
      pauseFooter.innerHTML = "&#9208;";
      pauseFooter.title = "Pause";
    }
    workshopDownloadBtn.disabled = false;
    workshopProgress.style.display = "none";
    var msgEl = document.getElementById("workshopStatusMessage");
    if (msgEl) {
      msgEl.textContent = "";
      msgEl.style.color = "rgba(249,115,22,0.9)";
    }
    var detEl = document.getElementById("workshopStatusDetails");
    if (detEl) detEl.textContent = "";
    var pctEl = document.getElementById("workshopProgressPercent");
    if (pctEl) pctEl.textContent = "";
    workshopProgressFill.style.width = "0%";
    workshopProgressFill.style.transform = "";
    workshopProgressFill.classList.remove("indeterminate");
    window._wsIndeterminate = false;
    hideProgress();
    setTimeout(refreshModsGrid, 300);
  }

  function findLibraryItem(id) {
    var items = modsItemsCache || [];
    for (var i = 0; i < items.length; i++) {
      if (items[i] && String(items[i].id) === String(id)) return items[i];
    }
    return null;
  }

  function doStartWorkshopDownload(id, displayName, update) {
    try {
      var ex = getExternal();
      if (!ex || !ex.workshopDownload) return;
      var libraryItem = findLibraryItem(id);
      var name = escapeHtml(
        (libraryItem && (libraryItem.name || libraryItem.folder)) ||
          displayName ||
          id
      );
      if (!update && ex.workshopCheckInstalled) {
        var inst = ex.workshopCheckInstalled(String(id));
        if (inst && inst.length > 0) {
          if (libraryItem && libraryItem.needsUpdate) {
            showConfirm(
              "Update available",
              "<strong>" +
                name +
                "</strong> is installed and a newer version is on the Workshop. Update it now?",
              function () {
                doStartWorkshopDownload(id, displayName, true);
              },
              "Update"
            );
          } else {
            showConfirm(
              "Already installed",
              "<strong>" +
                name +
                "</strong> is already installed. Download it again to get the latest version or repair missing files?",
              function () {
                doStartWorkshopDownload(id, displayName, true);
              },
              "Reinstall"
            );
          }
          return;
        }
      }
      var result =
        update && ex.workshopUpdate
          ? ex.workshopUpdate(String(id))
          : ex.workshopDownload(String(id));
      if (result && String(result).indexOf("Error:") === 0) {
        showMessage("Workshop", String(result).replace(/^Error:\s*/, ""));
        return;
      }
      var msgEl = document.getElementById("workshopStatusMessage");
      var detEl = document.getElementById("workshopStatusDetails");
      var pctEl = document.getElementById("workshopProgressPercent");
      if (msgEl) {
        msgEl.textContent = "Initializing...";
        msgEl.style.color = "rgba(249,115,22,0.9)";
      }
      if (detEl) detEl.textContent = "Workshop ID: " + id;
      if (pctEl) pctEl.textContent = "";
      window._lastWorkshopTerminalState = "";
      window._wsMaxProgress = 0;
      window._wsIndeterminate = true;
      workshopProgress.style.display = "block";
      workshopProgressFill.style.width = "0%";
      workshopProgressFill.classList.add("indeterminate");
      workshopDownloadBtn.disabled = true;
      showProgress(
        (update ? "Starting update for " : "Starting download for ") +
          (displayName || id) +
          "...",
        -1
      );
      if (window._workshopPollInterval) {
        clearInterval(window._workshopPollInterval);
      }
      window._workshopPollInterval = setInterval(pollWorkshopStatus, 500);
    } catch (e) {}
  }

  function startWorkshopDownload(id, displayName, update) {
    if (window._workshopPollInterval) {
      showConfirm(
        "Download in progress",
        'A download is already in progress. Stop it and download "' +
          (displayName || id) +
          '" instead?',
        function () {
          stopWorkshopDownloadCompletely();
          setTimeout(function () {
            doStartWorkshopDownload(id, displayName, update);
          }, 300);
        },
        "Switch"
      );
      return;
    }
    doStartWorkshopDownload(id, displayName, update);
  }

  function pollWorkshopStatus() {
    try {
      var ex = getExternal();
      if (!ex || !ex.workshopGetStatus) return;
      var statusJson = ex.workshopGetStatus();
      if (!statusJson || statusJson.length === 0) return;
      var status =
        typeof statusJson === "string" ? JSON.parse(statusJson) : statusJson;
      if (status.downloadFolder)
        _workshopDownloadFolder = status.downloadFolder;
      if (!window._lastWorkshopTerminalState)
        window._lastWorkshopTerminalState = "";

      if (status.paused !== undefined) {
        var pauseBtn = document.getElementById("workshopProgressPause");
        var pauseFooter = document.getElementById("progressPause");
        if (status.paused && !window._workshopIsPaused) {
          window._workshopIsPaused = true;
          if (pauseBtn) {
            pauseBtn.innerHTML = "&#9654;";
            pauseBtn.title = "Resume";
          }
          if (pauseFooter) {
            pauseFooter.innerHTML = "&#9654;";
            pauseFooter.title = "Resume";
          }
        } else if (!status.paused && window._workshopIsPaused) {
          window._workshopIsPaused = false;
          if (pauseBtn) {
            pauseBtn.innerHTML = "&#9208;";
            pauseBtn.title = "Pause";
          }
          if (pauseFooter) {
            pauseFooter.innerHTML = "&#9208;";
            pauseFooter.title = "Pause";
          }
        }
      }

      var msgEl = document.getElementById("workshopStatusMessage");
      var detEl = document.getElementById("workshopStatusDetails");
      var pctEl = document.getElementById("workshopProgressPercent");

      if (status.message && status.message.length > 0) {
        workshopProgress.style.display = "block";
        if (msgEl) msgEl.textContent = status.message;
        if (detEl) detEl.textContent = status.details || "";

        if (status.progress !== undefined && status.progress > 0) {
          if (window._wsIndeterminate) {
            window._wsIndeterminate = false;
            workshopProgressFill.classList.remove("indeterminate");
            workshopProgressFill.style.transform = "";
            var pf2 = document.getElementById("progressFill");
            if (pf2) {
              pf2.classList.remove("indeterminate");
              pf2.style.transform = "";
            }
          }
          var p = Math.min(status.progress, 99);
          workshopProgressFill.style.width = p + "%";
          if (pctEl) pctEl.textContent = p.toFixed(1) + "%";
          showProgress(status.message, p, status.details);
        } else {
          if (!window._wsIndeterminate) {
            window._wsIndeterminate = true;
            workshopProgressFill.classList.add("indeterminate");
            var pf3 = document.getElementById("progressFill");
            if (pf3) pf3.classList.add("indeterminate");
          }
          if (pctEl) pctEl.textContent = "";
          showProgress(status.message, -1, status.details);
        }

        var isDone = status.message.indexOf("Done") !== -1;
        var isError = status.message.indexOf("Error") !== -1;
        var isCanceled = status.message.indexOf("Canceled") !== -1;
        var isAlready = status.message.indexOf("Already installed") !== -1;

        if (isDone || isError || isCanceled || isAlready) {
          if (window._workshopPollInterval) {
            clearInterval(window._workshopPollInterval);
            window._workshopPollInterval = null;
          }
          workshopDownloadBtn.disabled = false;
          setTimeout(refreshModsGrid, 500);
          if (window._lastWorkshopTerminalState !== status.message) {
            window._lastWorkshopTerminalState = status.message;
            if (isDone) {
              if (msgEl) msgEl.style.color = "rgba(34,197,94,0.9)";
              showMessage(
                "Download Complete",
                status.details || "Workshop item installed successfully."
              );
            } else if (isCanceled) {
              if (msgEl) msgEl.style.color = "rgba(250,204,21,0.9)";
            } else if (isAlready) {
              if (msgEl) msgEl.style.color = "rgba(249,115,22,0.9)";
              showMessage(
                "Already Installed",
                status.details ||
                  "This item is already installed. Remove it first to reinstall."
              );
            } else {
              if (msgEl) msgEl.style.color = "rgba(239,68,68,0.9)";
              showMessage(
                "Workshop Error",
                status.message + (status.details ? "\n" + status.details : "")
              );
            }
          }
          if (isCanceled) {
            workshopProgress.style.display = "none";
            if (msgEl) msgEl.style.color = "rgba(249,115,22,0.9)";
            hideProgress();
          } else if (isAlready) {
            workshopProgress.style.display = "none";
            if (msgEl) msgEl.style.color = "rgba(249,115,22,0.9)";
            hideProgress();
          } else if (isDone) {
            if (workshopId) workshopId.value = "";
            setTimeout(function () {
              workshopProgress.style.display = "none";
              if (msgEl) msgEl.style.color = "rgba(249,115,22,0.9)";
            }, 4000);
            setTimeout(hideProgress, 4000);
          } else if (isError) {
            setTimeout(function () {
              workshopProgress.style.display = "none";
              if (msgEl) msgEl.style.color = "rgba(249,115,22,0.9)";
            }, 5000);
            setTimeout(hideProgress, 5000);
          }
        }
      }
    } catch (e) {}
  }

  workshopDownloadBtn.onclick = function () {
    var id = ((workshopId && workshopId.value) || "").replace(/^\s+|\s+$/g, "");
    if (!id) {
      if (workshopStatus)
        workshopStatus.textContent = "Enter a Workshop ID or link.";
      return;
    }
    startWorkshopDownload(id, id);
  };

  var workshopProgressCancel = document.getElementById(
    "workshopProgressCancel"
  );
  if (workshopProgressCancel)
    workshopProgressCancel.onclick = function () {
      stopWorkshopDownloadCompletely();
    };

  var workshopProgressPause = document.getElementById("workshopProgressPause");
  window._workshopIsPaused = false;
  if (workshopProgressPause) {
    workshopProgressPause.onclick = function () {
      try {
        var ex = getExternal();
        if (!ex) return;
        if (window._workshopIsPaused) {
          if (ex.workshopResumeDownload) ex.workshopResumeDownload();
          window._workshopIsPaused = false;
          workshopProgressPause.innerHTML = "&#9208;";
          workshopProgressPause.title = "Pause";
          var pf = document.getElementById("progressPause");
          if (pf) {
            pf.innerHTML = "&#9208;";
            pf.title = "Pause";
          }
        } else {
          if (ex.workshopPauseDownload) ex.workshopPauseDownload();
          window._workshopIsPaused = true;
          workshopProgressPause.innerHTML = "&#9654;";
          workshopProgressPause.title = "Resume";
          var pf2 = document.getElementById("progressPause");
          if (pf2) {
            pf2.innerHTML = "&#9654;";
            pf2.title = "Resume";
          }
        }
      } catch (e) {}
    };
  }

  var progressPauseBtn = document.getElementById("progressPause");
  if (progressPauseBtn) {
    progressPauseBtn.onclick = function () {
      if (workshopProgressPause) workshopProgressPause.click();
    };
  }

  document.getElementById("progressCancel").onclick = function () {
    stopWorkshopDownloadCompletely();
  };

  progressOpenFolder.onclick = function () {
    if (_workshopDownloadFolder && _workshopDownloadFolder.length > 0) {
      try {
        getExternal().openUrl(_workshopDownloadFolder);
      } catch (e) {}
    }
  };

  var _modsListPollInterval = null;
  var _removeProgressPollInterval = null;

  function getFilteredModsItems() {
    var items = modsItemsCache || [];
    var query = librarySearchInput
      ? (librarySearchInput.value || "").replace(/^\s+|\s+$/g, "").toLowerCase()
      : "";
    if (!query) return items.slice(0);
    var filtered = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i] || {};
      var searchable = [
        item.name,
        item.folder,
        item.type,
        item.description,
        item.id,
        item.source,
      ]
        .join(" ")
        .toLowerCase();
      if (searchable.indexOf(query) !== -1) filtered.push(item);
    }
    return filtered;
  }

  function updateLibraryCount(visibleCount) {
    if (!libraryItemCount) return;
    var total = (modsItemsCache || []).length;
    libraryItemCount.textContent =
      visibleCount === total ? String(total) : visibleCount + " / " + total;
  }

  function setLibraryRefreshing(refreshing) {
    modsRefreshInFlight = refreshing;
    if (!workshopRefreshBtn) return;
    workshopRefreshBtn.disabled = refreshing;
    workshopRefreshBtn.textContent = refreshing ? "Refreshing..." : "Refresh";
  }

  function applyLibraryViewMode() {
    var listMode = libraryViewMode === "list";
    modsPageSize = listMode ? 20 : 12;
    if (modsGrid) {
      if (listMode) modsGrid.classList.add("list-view");
      else modsGrid.classList.remove("list-view");
    }
    if (libraryViewToggleBtn) {
      libraryViewToggleBtn.textContent = listMode ? "Grid View" : "List View";
      libraryViewToggleBtn.setAttribute(
        "aria-pressed",
        listMode ? "true" : "false"
      );
    }
  }

  function removeLibraryItemFromCache(folderName, itemPath) {
    var folder = String(folderName || "").toLowerCase();
    var path = String(itemPath || "").toLowerCase();
    var remaining = [];
    for (var i = 0; i < modsItemsCache.length; i++) {
      var item = modsItemsCache[i] || {};
      var samePath = path && String(item.path || "").toLowerCase() === path;
      var sameFolder =
        folder && String(item.folder || "").toLowerCase() === folder;
      if (!samePath && !sameFolder) remaining.push(item);
    }
    modsItemsCache = remaining;
    renderModsPage();
  }

  if (librarySearchInput) {
    librarySearchInput.oninput = function () {
      modsPage = 1;
      renderModsPage();
    };
  }

  if (librarySearchClearBtn) {
    librarySearchClearBtn.onclick = function () {
      if (librarySearchInput) {
        librarySearchInput.value = "";
        librarySearchInput.focus();
      }
      modsPage = 1;
      renderModsPage();
    };
  }

  if (libraryViewToggleBtn) {
    libraryViewToggleBtn.onclick = function () {
      libraryViewMode = libraryViewMode === "list" ? "grid" : "list";
      try {
        localStorage.setItem("libraryViewMode", libraryViewMode);
      } catch (e) {}
      modsPage = 1;
      applyLibraryViewMode();
      renderModsPage();
    };
  }

  applyLibraryViewMode();

  function startRemoveProgressPoll() {
    var bar = document.getElementById("removeProgressBar");
    var msg = document.getElementById("removeMsg");
    var det = document.getElementById("removeDetails");
    var fill = document.getElementById("removeFill");
    if (!bar) return;
    bar.style.display = "block";
    if (msg) msg.textContent = "Removing...";
    if (det) det.textContent = "";
    if (fill) {
      fill.style.width = "0%";
      fill.classList.add("indeterminate");
    }
    if (_removeProgressPollInterval) clearInterval(_removeProgressPollInterval);
    var pollCount = 0;
    var removalFailure = "";
    _removeProgressPollInterval = setInterval(function () {
      pollCount++;
      if (pollCount > 600) {
        clearInterval(_removeProgressPollInterval);
        _removeProgressPollInterval = null;
        bar.style.display = "none";
        refreshModsGrid();
        return;
      }
      try {
        var ex = getExternal();
        if (!ex || !ex.getRemoveStatus) return;
        var sj = ex.getRemoveStatus();
        if (!sj) return;
        var st = typeof sj === "string" ? JSON.parse(sj) : sj;
        if (
          st.message &&
          (st.message.toLowerCase().indexOf("failed") !== -1 ||
            st.message.toLowerCase().indexOf("error") !== -1)
        )
          removalFailure = st.details || st.message;
        if (msg) msg.textContent = st.message || "Removing...";
        if (det) det.textContent = st.details || "";
        if (fill) {
          if (st.progress >= 0 && st.progress <= 100) {
            fill.classList.remove("indeterminate");
            fill.style.transform = "";
            fill.style.width = Math.min(st.progress, 100) + "%";
          } else {
            fill.classList.add("indeterminate");
            fill.style.width = "";
          }
        }
        if (!st.running) {
          clearInterval(_removeProgressPollInterval);
          _removeProgressPollInterval = null;
          setTimeout(function () {
            bar.style.display = "none";
            if (fill) {
              fill.classList.remove("indeterminate");
              fill.style.width = "0%";
              fill.style.transform = "";
            }
            refreshModsGrid();
            if (removalFailure) showMessage("Removal failed", removalFailure);
          }, 150);
        }
      } catch (e) {}
    }, 200);
  }

  function readLibraryList(ex) {
    var list = ex.workshopList();
    return list ? (typeof list === "string" ? JSON.parse(list) : list) : [];
  }

  function showLibraryState(icon, text) {
    modsGrid.innerHTML =
      '<div class="empty-state">' +
      icon +
      '<div class="empty-state-text">' +
      text +
      "</div></div>";
    if (modsPagination) modsPagination.style.display = "none";
  }

  function finishModsRefresh(items) {
    modsItemsCache = items;
    modsInitialized = true;
    renderModsPage();
    setLibraryRefreshing(false);
    if (modsRefreshQueued) {
      modsRefreshQueued = false;
      refreshModsGrid();
    }
  }

  function refreshModsGrid() {
    if (modsRefreshInFlight) {
      modsRefreshQueued = true;
      return;
    }
    var ex = getExternal();
    if (!ex || !ex.workshopListAsync) {
      modsInitialized = true;
      renderModsPage();
      return;
    }
    try {
      if (!modsInitialized) {
        var cached = readLibraryList(ex);
        if (cached.length) {
          finishModsRefresh(cached);
        } else {
          updateLibraryCount(0);
          showLibraryState(
            '<div class="loading-spinner"></div>',
            "Scanning installed items..."
          );
        }
      }
      setLibraryRefreshing(true);
      ex.workshopListAsync();
      if (_modsListPollInterval) clearInterval(_modsListPollInterval);
      var polls = 0;
      _modsListPollInterval = setInterval(function () {
        try {
          if (ex.workshopListIsLoading() === "true" && ++polls < 300) return;
          clearInterval(_modsListPollInterval);
          _modsListPollInterval = null;
          finishModsRefresh(readLibraryList(ex));
        } catch (e) {
          clearInterval(_modsListPollInterval);
          _modsListPollInterval = null;
          setLibraryRefreshing(false);
          if (!modsItemsCache.length)
            showLibraryState(
              '<div class="empty-state-icon">&#9888;</div>',
              "Error loading workshop items"
            );
        }
      }, 100);
    } catch (e) {
      setLibraryRefreshing(false);
      if (!modsItemsCache.length)
        showLibraryState(
          '<div class="empty-state-icon">&#9888;</div>',
          "Error loading workshop items"
        );
    }
  }

  function renderModsPage() {
    modsGrid.innerHTML = "";
    var visibleItems = getFilteredModsItems();
    updateLibraryCount(visibleItems.length);
    if (!modsItemsCache || modsItemsCache.length === 0) {
      modsGrid.innerHTML =
        '<div class="empty-state"><div class="empty-state-icon">&#128230;</div><div class="empty-state-text">No workshop items installed yet</div></div>';
      if (modsPagination) modsPagination.style.display = "none";
      return;
    }
    if (visibleItems.length === 0) {
      modsGrid.innerHTML =
        '<div class="empty-state"><div class="empty-state-icon">&#128269;</div><div class="empty-state-text">No installed items match your search</div></div>';
      if (modsPagination) modsPagination.style.display = "none";
      return;
    }
    var totalPages = Math.ceil(visibleItems.length / modsPageSize) || 1;
    if (modsPage < 1) modsPage = 1;
    if (modsPage > totalPages) modsPage = totalPages;
    var start = (modsPage - 1) * modsPageSize;
    var end = Math.min(start + modsPageSize, visibleItems.length);
    var fragment = document.createDocumentFragment();
    for (var i = start; i < end; i++) {
      var item = visibleItems[i];
      var card = document.createElement("div");
      card.className = "mod-card";

      var header = document.createElement("div");
      header.className = "mod-card-header";

      var nameDiv = document.createElement("div");
      nameDiv.className = "mod-card-name";
      nameDiv.textContent = item.name || item.folder;
      nameDiv.title = item.name || item.folder;

      var typeDiv = document.createElement("div");
      typeDiv.className = "mod-card-type";
      var typeText =
        (item.type || "mod") + (item.source === "steam" ? " (Steam)" : "");
      if (item.needsUpdate) {
        typeDiv.innerHTML =
          typeText +
          ' <span style="color:#ff7a2f;font-weight:bold;margin-left:4px;">&#x21bb; Update</span>';
      } else {
        typeDiv.textContent = typeText;
      }
      header.appendChild(nameDiv);
      header.appendChild(typeDiv);

      var descDiv = null;
      var descText = item.description || "";
      if (descText.length > 0) {
        descDiv = document.createElement("div");
        descDiv.className = "mod-card-description";
        var rawDesc = stripBBCode(descText.replace(/[\r\n]+/g, " "));
        var shortDesc = rawDesc.substring(0, 90);
        if (rawDesc.length > 90) shortDesc += "...";
        descDiv.textContent = shortDesc;
      }

      var metaDiv = document.createElement("div");
      metaDiv.className = "mod-card-meta";
      var hasMeta = false;

      var lSz = parseInt(item.localSize, 10) || 0;
      var aSz = parseInt(item.file_size, 10) || 0;
      var sz = lSz > 0 ? lSz : aSz;
      if (sz > 0) {
        var szStr = formatSize(sz);
        var sizeSpan = document.createElement("span");
        sizeSpan.innerHTML =
          '<span class="meta-icon">&#128190;</span> ' + szStr;
        metaDiv.appendChild(sizeSpan);
        hasMeta = true;
      }

      var sr = parseInt(item.starRating, 10) || 0;
      if (sr > 0) {
        var sStr2 = "";
        for (var s = 0; s < sr; s++) sStr2 += "\u2605";
        for (var s = sr; s < 5; s++) sStr2 += "\u2606";
        var rColor2 =
          sr >= 4
            ? "rgba(34,197,94,0.75)"
            : sr >= 3
              ? "rgba(250,204,21,0.75)"
              : "rgba(239,68,68,0.75)";
        var ratingSpan = document.createElement("span");
        ratingSpan.style.color = rColor2;
        ratingSpan.textContent = sStr2;
        metaDiv.appendChild(ratingSpan);
        hasMeta = true;
      }

      var mSubs = parseInt(item.subs, 10) || 0;
      if (mSubs > 0) {
        var subsSpan = document.createElement("span");
        subsSpan.innerHTML =
          '<span class="meta-icon">&#128101;</span> ' + mSubs.toLocaleString();
        metaDiv.appendChild(subsSpan);
        hasMeta = true;
      }

      var actions = document.createElement("div");
      actions.className = "mod-card-actions";

      if (item.id && String(item.id).length > 0) {
        var viewBtn = document.createElement("button");
        viewBtn.className = "btn";
        viewBtn.type = "button";
        viewBtn.textContent = "View";
        viewBtn.setAttribute(
          "data-open-url",
          "https://steamcommunity.com/sharedfiles/filedetails/?id=" +
            String(item.id)
        );
        actions.appendChild(viewBtn);

        var updateBtn = document.createElement("button");
        updateBtn.className = "btn";
        if (item.needsUpdate) {
          updateBtn.style.background =
            "linear-gradient(145deg,rgba(249,115,22,0.45),rgba(220,90,12,0.35))";
          updateBtn.style.borderColor = "rgba(249,115,22,0.7)";
          updateBtn.style.fontWeight = "bold";
        }
        updateBtn.type = "button";
        updateBtn.textContent = item.needsUpdate ? "Update Now" : "Update";
        (function (itemId, itemName) {
          updateBtn.onclick = function (e) {
            e.stopPropagation();
            startWorkshopDownload(itemId, itemName, true);
          };
        })(item.id, item.name || item.folder);
        actions.appendChild(updateBtn);
      }

      var removeBtn = document.createElement("button");
      removeBtn.className = "btn btn-remove";
      removeBtn.type = "button";
      removeBtn.textContent = "Remove";
      (function (folderName, itemName, itemPath) {
        removeBtn.onclick = function (e) {
          e.stopPropagation();
          if (!folderName && !itemPath) {
            showMessage("Remove", "Cannot remove: folder name is missing.");
            return;
          }
          var rb =
            "Remove <strong>" +
            (itemName || folderName).replace(/</g, "&lt;") +
            "</strong> from your game folder?";
          showConfirm("Remove workshop item", rb, function () {
            var ex = getExternal();
            if (!ex) {
              showMessage("Remove", "Workshop remove is not available.");
              return;
            }
            var done = false;
            var removeResult = "";
            if (itemPath) {
              try {
                removeResult = ex.workshopRemoveByPath(itemPath);
                done = removeResult === "started";
              } catch (e1) {}
              if (!done)
                try {
                  removeResult = ex.invoke("workshopRemoveByPath", itemPath);
                  done = removeResult === "started";
                } catch (e2) {}
            } else {
              try {
                removeResult = ex.workshopRemove(folderName);
                done = removeResult === "started";
              } catch (e1) {}
              if (!done)
                try {
                  removeResult = ex.invoke("workshopRemove", folderName);
                  done = removeResult === "started";
                } catch (e2) {}
            }
            if (done) {
              removeLibraryItemFromCache(folderName, itemPath);
              startRemoveProgressPoll();
            } else if (removeResult === "already_running") {
              showMessage("Remove", "Another removal is already running.");
            } else {
              showMessage("Remove", "Workshop remove is not available.");
            }
          });
        };
      })(item.folder || "", item.name || item.folder, item.path || "");
      actions.appendChild(removeBtn);

      var body = document.createElement("div");
      body.className = "mod-card-body";
      body.appendChild(header);
      if (descDiv) body.appendChild(descDiv);
      if (hasMeta) body.appendChild(metaDiv);
      body.appendChild(actions);

      if (item.image && String(item.image).length > 0) {
        var imgWrap = document.createElement("div");
        imgWrap.className = "mod-card-image-wrap";
        var img = document.createElement("img");
        img.src = item.image;
        img.alt = "";
        img.loading = "lazy";
        img.decoding = "async";
        img.onerror = (function (wrap) {
          return function () {
            if (wrap && wrap.parentNode) wrap.parentNode.removeChild(wrap);
          };
        })(imgWrap);
        imgWrap.appendChild(img);
        card.appendChild(imgWrap);
      }

      card.appendChild(body);
      card.onclick = (function (it) {
        return function (e) {
          if (e.target.closest && e.target.closest(".mod-card-actions")) return;
          showLibraryModModal(it);
        };
      })(item);
      fragment.appendChild(card);
    }
    modsGrid.appendChild(fragment);

    if (modsPagination) {
      if (totalPages > 1) {
        modsPagination.style.display = "flex";
        if (modsPageLabel)
          modsPageLabel.textContent = "Page " + modsPage + " / " + totalPages;
        if (modsPrevPageBtn) modsPrevPageBtn.disabled = modsPage <= 1;
        if (modsNextPageBtn) modsNextPageBtn.disabled = modsPage >= totalPages;
      } else {
        modsPagination.style.display = "none";
      }
    }
  }

  modsGrid.onclick = function (e) {
    var t = e.target;
    while (t && t !== modsGrid) {
      var url = t.getAttribute && t.getAttribute("data-open-url");
      if (url) {
        e.preventDefault();
        e.stopPropagation();
        try {
          getExternal().openUrl(url);
        } catch (err) {}
        return;
      }
      t = t.parentNode;
    }
  };

  if (modsPrevPageBtn) {
    modsPrevPageBtn.onclick = function () {
      if (modsPage > 1) {
        modsPage--;
        renderModsPage();
      }
    };
  }

  if (modsNextPageBtn) {
    modsNextPageBtn.onclick = function () {
      var tp = Math.ceil(getFilteredModsItems().length / modsPageSize) || 1;
      if (modsPage < tp) {
        modsPage++;
        renderModsPage();
      }
    };
  }

  if (workshopRefreshBtn)
    workshopRefreshBtn.onclick = function () {
      refreshModsGrid();
    };

  document.getElementById("deleteAllModsBtn").onclick = function () {
    var items = modsItemsCache || [];
    var lh =
      '<p style="margin:0 0 8px 0;">Remove <strong>' +
      items.length +
      "</strong> workshop item" +
      (items.length !== 1 ? "s" : "") +
      " from your game folder? This cannot be undone.</p>";
    if (items.length > 0) {
      lh += '<ul class="confirm-item-list">';
      for (var ci = 0; ci < items.length; ci++) {
        var cItem = items[ci];
        var cName = (cItem.name || cItem.folder || "Unknown").replace(
          /</g,
          "&lt;"
        );
        var cSz2 =
          parseInt(cItem.localSize, 10) || parseInt(cItem.file_size, 10) || 0;
        var cSzStr = cSz2 > 0 ? formatSize(cSz2) : "";
        lh +=
          '<li><span class="item-name">' +
          cName +
          "</span>" +
          (cSzStr ? '<span class="item-size">' + cSzStr + "</span>" : "") +
          "</li>";
      }
      lh += "</ul>";
    }
    showConfirm("Delete all mods", lh, function () {
      var ex = getExternal();
      if (!ex) return;
      var done = false;
      var removeResult = "";
      try {
        removeResult = ex.workshopRemoveAll();
        done = removeResult === "started";
      } catch (e1) {}
      if (!done)
        try {
          removeResult = ex.invoke("workshopRemoveAll", "");
          done = removeResult === "started";
        } catch (e2) {}
      if (done) {
        modsItemsCache = [];
        modsPage = 1;
        renderModsPage();
        startRemoveProgressPoll();
      } else if (removeResult === "already_running") {
        showMessage("Delete all mods", "Another removal is already running.");
      }
    });
  };

  document.getElementById("checkUpdatesBtn").onclick = function () {
    var wsStatus = document.getElementById("workshopStatus");
    try {
      var ex = getExternal();
      if (!ex || !ex.workshopList) {
        if (wsStatus) wsStatus.textContent = "Cannot check updates.";
        return;
      }
      document.getElementById("checkUpdatesBtn").disabled = true;
      if (ex.workshopListAsync) ex.workshopListAsync();
      var cpCount = 0;
      var checkPoll = setInterval(function () {
        cpCount++;
        if (cpCount > 300) {
          clearInterval(checkPoll);
          document.getElementById("checkUpdatesBtn").disabled = false;
          return;
        }
        try {
          var ex2 = getExternal();
          if (!ex2) return;
          var isLoading =
            ex2.workshopListIsLoading && ex2.workshopListIsLoading() === "true";
          if (!isLoading) {
            clearInterval(checkPoll);
            var list = ex2.workshopList();
            if (!list || list.length === 0) {
              document.getElementById("checkUpdatesBtn").disabled = false;
              return;
            }
            var items2 = typeof list === "string" ? JSON.parse(list) : list;
            modsItemsCache = items2;
            modsPage = 1;
            renderModsPage();
            var toUpdate = [];
            for (var ui = 0; ui < items2.length; ui++) {
              if (
                items2[ui].needsUpdate &&
                items2[ui].id &&
                String(items2[ui].id).length > 0
              )
                toUpdate.push(items2[ui]);
            }
            if (toUpdate.length === 0) {
              document.getElementById("checkUpdatesBtn").disabled = false;
              showMessage("Updates", "All items are up to date!");
              return;
            }
            workshopProgress.style.display = "block";
            workshopDownloadBtn.disabled = true;
            window._workshopCanceled = false;
            var idx = 0;
            function updateNext() {
              if (idx >= toUpdate.length || window._workshopCanceled) {
                workshopDownloadBtn.disabled = false;
                document.getElementById("checkUpdatesBtn").disabled = false;
                setTimeout(refreshModsGrid, 500);
                return;
              }
              var it = toUpdate[idx];
              try {
                if (ex2.workshopUpdate) ex2.workshopUpdate(String(it.id));
                else ex2.workshopDownload(String(it.id));
              } catch (e) {}
              var upi = setInterval(function () {
                if (window._workshopCanceled) {
                  clearInterval(upi);
                  updateNext();
                  return;
                }
                pollWorkshopStatus();
                var ex3 = getExternal();
                if (ex3 && ex3.workshopGetStatus) {
                  var sj = ex3.workshopGetStatus();
                  if (sj) {
                    var st = typeof sj === "string" ? JSON.parse(sj) : sj;
                    if (
                      st.message &&
                      (st.message.indexOf("Done") !== -1 ||
                        st.message.indexOf("Error") !== -1 ||
                        st.message.indexOf("Already installed") !== -1)
                    ) {
                      clearInterval(upi);
                      idx++;
                      setTimeout(updateNext, 300);
                    }
                  }
                }
              }, 500);
            }
            updateNext();
          }
        } catch (e) {
          document.getElementById("checkUpdatesBtn").disabled = false;
        }
      }, 100);
    } catch (e) {
      document.getElementById("checkUpdatesBtn").disabled = false;
    }
  };

  document.getElementById("manageInstallBtn").onclick = function () {
    if (manageInstallPopup) manageInstallPopup.classList.add("active");
    loadComponents();
  };

  function hideManagePopup() {
    if (manageInstallPopup) manageInstallPopup.classList.remove("active");
  }
  manageInstallPopup.querySelector(".popup-close").onclick = hideManagePopup;
  document.getElementById("popupCancel").onclick = hideManagePopup;
  manageInstallPopup.onclick = function (e) {
    if (e.target === manageInstallPopup) hideManagePopup();
  };

  var componentSelection = {
    campaign: false,
    multiplayer: false,
    zombies: false,
  };
  var modeFilesInfo = {};

  function loadComponents() {
    var list = document.getElementById("componentsList");
    list.innerHTML =
      '<div style="text-align:center;padding:16px;color:rgba(200,196,192,0.5);">Scanning files...</div>';
    componentSelection = {
      campaign: false,
      multiplayer: false,
      zombies: false,
    };
    try {
      var ex = getExternal();
      if (ex && ex.getModeFilesInfo) {
        var raw = ex.getModeFilesInfo();
        modeFilesInfo = typeof raw === "string" ? JSON.parse(raw) : raw;
      } else {
        modeFilesInfo = {};
      }
    } catch (e) {
      modeFilesInfo = {};
    }
    var items = [
      { id: "campaign", name: "Campaign", prefix: "cp_" },
      { id: "multiplayer", name: "Multiplayer", prefix: "mp_" },
      { id: "zombies", name: "Zombies", prefix: "zm_" },
    ];
    list.innerHTML = "";
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var info = modeFilesInfo[it.id] || {
        count: 0,
        size: 0,
        sizeHuman: "0 B",
      };
      var installed = info.count > 0;
      var sizeText = installed
        ? info.sizeHuman + " (" + info.count + " files)"
        : "Not installed";
      var div = document.createElement("div");
      div.className = "component-item";
      if (!installed) div.style.opacity = "0.5";
      div.innerHTML =
        '<div class="component-checkbox">' +
        '<input type="checkbox" id="comp-' +
        it.id +
        '" data-comp="' +
        it.id +
        '"' +
        (installed ? "" : " disabled") +
        ">" +
        '<span class="checkbox-visual"></span></div>' +
        '<div class="component-info"><div class="component-name">' +
        it.name +
        "</div>" +
        '<span class="component-size">' +
        sizeText +
        "</span></div>";
      list.appendChild(div);
      if (installed) {
        var cb = div.querySelector('input[type="checkbox"]');
        cb.onchange = function () {
          componentSelection[this.getAttribute("data-comp")] = this.checked;
        };
        div.onclick = function (e) {
          if (e.target.type !== "checkbox") {
            var inp = this.querySelector('input[type="checkbox"]');
            if (inp && !inp.disabled) {
              inp.checked = !inp.checked;
              componentSelection[inp.getAttribute("data-comp")] = inp.checked;
            }
          }
        };
      }
    }
  }

  document.getElementById("popupApply").onclick = function () {
    var selected = [];
    var names = [];
    var prefixMap = { campaign: "cp_", multiplayer: "mp_", zombies: "zm_" };
    var nameMap = {
      campaign: "Campaign",
      multiplayer: "Multiplayer",
      zombies: "Zombies",
    };
    for (var key in componentSelection) {
      if (
        componentSelection[key] &&
        modeFilesInfo[key] &&
        modeFilesInfo[key].count > 0
      ) {
        selected.push(prefixMap[key]);
        names.push(nameMap[key] + " (" + modeFilesInfo[key].sizeHuman + ")");
      }
    }
    if (selected.length === 0) {
      showMessage(
        "Delete",
        "No game modes selected or selected modes have no files."
      );
      return;
    }
    hideManagePopup();
    showConfirm(
      "Delete Game Modes",
      "Are you sure you want to remove " +
        names.join(", ") +
        "? This cannot be undone.",
      function () {
        try {
          var ex = getExternal();
          if (ex && ex.removeModeFiles) {
            var result = ex.removeModeFiles(selected.join(","));
            var r = typeof result === "string" ? JSON.parse(result) : result;
            var msg =
              "Removed " + r.removedCount + " files (" + r.removedSize + ")";
            if (r.failedCount > 0)
              msg += "\nFailed to remove " + r.failedCount + " files";
            showMessage("Delete Complete", msg);
          }
        } catch (e) {
          showMessage("Error", "Failed to remove files: " + e.message);
        }
      }
    );
  };

  (function () {
    var verifyPopup = document.getElementById("verifyPopup");
    var verifyStartBtn = document.getElementById("verifyStartBtn");
    var verifyCancelBtn = document.getElementById("verifyCancelBtn");
    var verifyProgressSection = document.getElementById(
      "verifyProgressSection"
    );
    var verifyStatusMsg = document.getElementById("verifyStatusMsg");
    var verifyProgressFill2 = document.getElementById("verifyProgressFill");
    var verifyProgressPct = document.getElementById("verifyProgressPct");
    var verifyStatusDetails = document.getElementById("verifyStatusDetails");
    var verifyResults = document.getElementById("verifyResults");
    var verifyCloseBtn = document.getElementById("verifyPopupClose");
    var verifyModeBtns = document.querySelectorAll(".verify-mode-btn");
    var selectedVerifyMode = "all";
    var verifyPollInterval = null;
    var verifySeenRunning = false;
    var verifyMaxPct = 0;

    function resetVerifyUI() {
      verifyProgressSection.classList.remove("active");
      verifyResults.classList.remove("active");
      verifyResults.innerHTML = "";
      verifyStartBtn.style.display = "";
      verifyStartBtn.textContent = "Start Verification";
      verifyCancelBtn.style.display = "none";
      verifyProgressFill2.style.width = "0%";
      verifyProgressPct.textContent = "0%";
      verifyStatusMsg.textContent = "";
      verifyStatusMsg.style.color = "";
      verifyStatusDetails.textContent = "";
      verifySeenRunning = false;
      verifyMaxPct = 0;
      for (var i = 0; i < verifyModeBtns.length; i++)
        verifyModeBtns[i].disabled = false;
    }

    function showVerifyPopup() {
      resetVerifyUI();
      verifyPopup.classList.add("active");
    }
    function hideVerifyPopup() {
      if (verifyPollInterval) {
        clearInterval(verifyPollInterval);
        verifyPollInterval = null;
      }
      verifyPopup.classList.remove("active");
      resetVerifyUI();
    }

    function showVerifyResults(changedFiles, message) {
      verifyResults.innerHTML = "";
      verifyResults.classList.add("active");
      if (!changedFiles || changedFiles.length === 0) {
        verifyResults.innerHTML =
          '<div class="verify-results-ok">&#10004; All files verified — no changes detected.</div>';
      } else {
        var html =
          '<div style="color:rgba(249,115,22,0.9);font-size:0.78rem;font-weight:600;margin-bottom:7px;">' +
          changedFiles.length +
          " file" +
          (changedFiles.length > 1 ? "s" : "") +
          " with issues:</div>";
        html += '<div class="verify-results-bad">';
        for (var i = 0; i < changedFiles.length; i++) {
          var raw = changedFiles[i];
          var isWarning = raw.indexOf("[warning]") === 0;
          var display = raw.replace(/^\[(warning|error)\]\s*/, "");
          var color = isWarning
            ? "color:rgba(234,179,8,0.88)"
            : "color:rgba(239,68,68,0.88)";
          html +=
            '<div class="verify-file-item" style="' +
            color +
            '">' +
            escapeHtml(display) +
            "</div>";
        }
        html += "</div>";
        verifyResults.innerHTML = html;
      }
    }

    document.getElementById("verifyBtn").onclick = function () {
      showVerifyPopup();
    };

    verifyCloseBtn.onclick = function () {
      try {
        var ex = getExternal();
        if (ex && ex.cancelVerify) ex.cancelVerify();
      } catch (e) {}
      hideVerifyPopup();
    };

    verifyPopup.onclick = function (e) {
      if (e.target === verifyPopup) {
        try {
          var ex = getExternal();
          if (ex && ex.cancelVerify) ex.cancelVerify();
        } catch (e2) {}
        hideVerifyPopup();
      }
    };

    for (var vi = 0; vi < verifyModeBtns.length; vi++) {
      (function (btn) {
        btn.onclick = function () {
          for (var j = 0; j < verifyModeBtns.length; j++)
            verifyModeBtns[j].classList.remove("selected");
          btn.classList.add("selected");
          selectedVerifyMode = btn.getAttribute("data-mode");
        };
      })(verifyModeBtns[vi]);
    }

    verifyCancelBtn.onclick = function () {
      try {
        var ex = getExternal();
        if (ex && ex.cancelVerify) ex.cancelVerify();
      } catch (e) {}
      verifyCancelBtn.disabled = true;
    };

    function startVerify() {
      try {
        var ex = getExternal();
        if (!ex) {
          showMessage("Error", "Verification not available.");
          return;
        }
        var result = ex.verifyGameFiles(selectedVerifyMode);
        if (result === "already_running") {
          showMessage("Verify", "Verification is already running.");
          return;
        }
        verifySeenRunning = false;
        verifyResults.classList.remove("active");
        verifyResults.innerHTML = "";
        verifyStartBtn.style.display = "none";
        verifyCancelBtn.style.display = "";
        verifyCancelBtn.disabled = false;
        verifyProgressSection.classList.add("active");
        for (var k = 0; k < verifyModeBtns.length; k++)
          verifyModeBtns[k].disabled = true;

        verifyPollInterval = setInterval(function () {
          try {
            var ex2 = getExternal();
            if (!ex2 || !ex2.getVerifyStatus) return;
            var raw = ex2.getVerifyStatus();
            var st = typeof raw === "string" ? JSON.parse(raw) : raw;
            if (st.running) verifySeenRunning = true;
            if (!st.running && st.progress >= 100) verifySeenRunning = true;
            if (
              !st.running &&
              !verifySeenRunning &&
              st.message &&
              st.message.length > 0
            ) {
              clearInterval(verifyPollInterval);
              verifyPollInterval = null;
              verifyCancelBtn.style.display = "none";
              verifyStatusMsg.textContent = st.message;
              verifyStatusMsg.style.color = "#ef4444";
              verifyStartBtn.style.display = "";
              verifyStartBtn.textContent = "Close";
              verifyStartBtn.onclick = function () {
                hideVerifyPopup();
                verifyStartBtn.onclick = startVerify;
                verifyStartBtn.textContent = "Start Verification";
              };
              for (var k = 0; k < verifyModeBtns.length; k++)
                verifyModeBtns[k].disabled = false;
              return;
            }
            if (!verifySeenRunning) return;
            var rawPct = Math.min(st.progress || 0, 100);
            if (rawPct > verifyMaxPct) verifyMaxPct = rawPct;
            var pct = verifyMaxPct;
            verifyStatusMsg.textContent = st.message || "";
            if (
              st.message &&
              (st.message.indexOf("missing") !== -1 ||
                st.message.indexOf("wrong size") !== -1 ||
                st.message.indexOf("Not installed") !== -1 ||
                st.message.indexOf("No files found") !== -1)
            ) {
              verifyStatusMsg.style.color = "#ef4444";
            } else {
              verifyStatusMsg.style.color = "";
            }
            verifyProgressFill2.style.width = pct.toFixed(1) + "%";
            verifyProgressPct.textContent = pct.toFixed(1) + "%";
            verifyStatusDetails.textContent = st.details || "";
            if (!st.running && st.progress >= 100) {
              clearInterval(verifyPollInterval);
              verifyPollInterval = null;
              verifyCancelBtn.style.display = "none";
              verifyProgressFill2.style.width = "100%";
              verifyProgressPct.textContent = "100%";
              var isBaseline =
                st.message && st.message.indexOf("Baseline") !== -1;
              if (isBaseline) {
                verifyResults.classList.add("active");
                verifyResults.innerHTML =
                  '<div class="verify-results-ok">&#10004; ' +
                  escapeHtml(st.message) +
                  "</div>";
              } else {
                showVerifyResults(st.changedFiles || [], st.message);
              }
              for (var k = 0; k < verifyModeBtns.length; k++)
                verifyModeBtns[k].disabled = false;
              verifyStartBtn.textContent = "Verify Again";
              verifyStartBtn.style.display = "";
              verifyStartBtn.onclick = startVerify;
            } else if (
              !st.running &&
              st.message &&
              (st.message.indexOf("Cancelled") !== -1 ||
                st.message.indexOf("No game files") !== -1)
            ) {
              clearInterval(verifyPollInterval);
              verifyPollInterval = null;
              verifyCancelBtn.style.display = "none";
              verifyStartBtn.style.display = "";
              verifyStartBtn.textContent = "Start Verification";
              verifyStartBtn.onclick = startVerify;
              for (var k = 0; k < verifyModeBtns.length; k++)
                verifyModeBtns[k].disabled = false;
            }
          } catch (e) {}
        }, 200);
      } catch (e) {
        showMessage(
          "Error",
          "Failed to start verification: " + (e.message || "")
        );
      }
    }

    verifyStartBtn.onclick = startVerify;
  })();

  document.getElementById("playBtn").onclick = function () {
    try {
      var opts = window.getSelectedLaunchOption();

      var selectedVersion = _selectedVersion || "latest";
      var exeName = "";
      var exeUrl = "";

      if (selectedVersion !== "latest" && _versionsData[selectedVersion]) {
        exeName = _versionsData[selectedVersion].name;
        exeUrl = _versionsData[selectedVersion].url;
        if (
          selectedVersion !== "beta" &&
          opts.toLowerCase().indexOf("-noupdate") === -1
        ) {
          opts = (opts + " -noupdate").trim();
        }
      }

      var launchOptionTokens = opts.toLowerCase().split(/\s+/);
      var hasKeepLauncher =
        launchOptionTokens.indexOf("keep-launcher") !== -1 ||
        launchOptionTokens.indexOf("keeplauncher") !== -1;
      var keepLauncher = hasKeepLauncher || !getSetting("closeLauncher");
      if (window._workshopPollInterval && !keepLauncher) {
        showConfirm(
          "Download in progress",
          "A workshop download is in progress. Keep the launcher open while you play?",
          function () {
            try {
              if (exeName && exeUrl) {
                getExternal().launchGame(
                  window.getPlayerName(),
                  opts,
                  exeName,
                  exeUrl
                );
              } else {
                getExternal().launchGame(window.getPlayerName(), opts);
              }
            } catch (e2) {}
          }
        );
        return;
      }

      if (keepLauncher) {
        if (exeName && exeUrl) {
          getExternal().launchGame(
            window.getPlayerName(),
            opts,
            exeName,
            exeUrl
          );
        } else {
          getExternal().launchGame(window.getPlayerName(), opts);
        }
        return;
      }

      if (exeName && exeUrl) {
        getExternal().runGame(window.getPlayerName(), opts, exeName, exeUrl);
      } else {
        getExternal().runGame(window.getPlayerName(), opts);
      }
    } catch (e) {}
  };

  function setupPathBtn(btnId, pathDisplayIds) {
    var btn = document.getElementById(btnId);
    if (!btn) return;
    btn.onclick = function () {
      try {
        var ex = getExternal();
        if (!ex || !ex.openFolderPicker) return;
        var r = ex.openFolderPicker();
        if (r === "busy") return;
        btn.disabled = true;
        var poll = setInterval(function () {
          try {
            var ex2 = getExternal();
            if (!ex2 || !ex2.getFolderPickerResult) {
              clearInterval(poll);
              btn.disabled = false;
              return;
            }
            var result = ex2.getFolderPickerResult();
            if (result === "pending") return;
            clearInterval(poll);
            btn.disabled = false;
            if (result === "cancelled") return;
            if (result === "invalid") {
              showMessage(
                "Invalid Folder",
                "The selected folder does not contain BlackOps3.exe."
              );
              return;
            }
            for (var di = 0; di < pathDisplayIds.length; di++) {
              var el = document.getElementById(pathDisplayIds[di]);
              if (el) el.textContent = result;
            }
            showMessage(
              "Game Path Updated",
              "Game path set to:\n" +
                result +
                "\n\nRestart BOIII for the change to take full effect."
            );
          } catch (e) {
            clearInterval(poll);
            btn.disabled = false;
          }
        }, 200);
      } catch (e) {
        btn.disabled = false;
      }
    };
  }

  setupPathBtn("setPathBtn", ["currentPathDisplay", "settingsPathDisplay"]);
  setupPathBtn("settingsChangePathBtn", [
    "currentPathDisplay",
    "settingsPathDisplay",
  ]);

  (function () {
    var patchBtn = document.getElementById("installCompatibleClientBtn");
    var patchStatus = document.getElementById("installCompatibleClientStatus");
    if (!patchBtn) return;

    patchBtn.onclick = function () {
      var ex = getExternal();
      if (!ex || !ex.installCompatibleClient) {
        if (patchStatus)
          patchStatus.textContent =
            "This launcher cannot install the executable; use the manual link below.";
        return;
      }

      patchBtn.disabled = true;
      if (patchStatus) patchStatus.textContent = "Checking BlackOps3.exe...";

      var result = "";
      try {
        result = String(ex.installCompatibleClient());
      } catch (e) {
        result = "error";
      }

      if (result === "supported") {
        if (patchStatus)
          patchStatus.textContent =
            "Your BlackOps3.exe is already the compatible build (PE checksum 0x6531394).";
        patchBtn.disabled = false;
        return;
      }

      if (result === "unreadable") {
        if (patchStatus)
          patchStatus.textContent =
            "BlackOps3.exe could not be read. Check the game folder, then verify the game files in Steam.";
        patchBtn.disabled = false;
        return;
      }

      if (result === "started") {
        if (patchStatus)
          patchStatus.textContent =
            "Download started in the patch installer window. Your current file is backed up first.";
        return;
      }

      if (patchStatus)
        patchStatus.textContent =
          "The patch installer is not available in this build; use the manual link below.";
      patchBtn.disabled = false;
    };
  })();

  var settingsTabs = document.querySelectorAll(".settings-tab");
  var settingsTabContents = document.querySelectorAll(".settings-tab-content");
  for (var sti = 0; sti < settingsTabs.length; sti++) {
    (function (tab) {
      tab.onclick = function () {
        var target = tab.getAttribute("data-stab");
        for (var j = 0; j < settingsTabs.length; j++)
          settingsTabs[j].classList.remove("active");
        for (var j = 0; j < settingsTabContents.length; j++)
          settingsTabContents[j].classList.remove("active");
        tab.classList.add("active");
        var contentEl = document.querySelector(
          '.settings-tab-content[data-stab="' + target + '"]'
        );
        if (contentEl) contentEl.classList.add("active");
        if (target === "binds") loadBinds();
      };
    })(settingsTabs[sti]);
  }

  var bindKeyInput = document.getElementById("bindKeyInput");
  var bindCommandInput = document.getElementById("bindCommandInput");
  var bindSaveBtn = document.getElementById("bindSaveBtn");
  var bindList = document.getElementById("bindList");

  function loadBinds() {
    if (!bindList) return;
    bindList.innerHTML = "";
    var binds = [];
    try {
      var ex = getExternal();
      if (ex && ex.readBinds) binds = JSON.parse(ex.readBinds() || "[]");
    } catch (e) {}
    if (!binds.length) {
      var empty = document.createElement("div");
      empty.className = "bind-empty";
      empty.textContent = "No custom binds saved.";
      bindList.appendChild(empty);
      return;
    }
    for (var bi = 0; bi < binds.length; bi++) {
      (function (bind) {
        var row = document.createElement("div");
        row.className = "bind-row";
        var key = document.createElement("span");
        key.className = "bind-row-key";
        key.textContent = bind.key;
        var command = document.createElement("span");
        command.className = "bind-row-command";
        command.textContent = bind.command;
        var actions = document.createElement("div");
        actions.className = "bind-row-actions";
        var edit = document.createElement("button");
        edit.type = "button";
        edit.className = "btn";
        edit.textContent = "Edit";
        edit.onclick = function () {
          bindKeyInput.value = bind.key;
          bindCommandInput.value = bind.command;
          bindCommandInput.focus();
        };
        var remove = document.createElement("button");
        remove.type = "button";
        remove.className = "btn btn-danger";
        remove.textContent = "Remove";
        remove.onclick = function () {
          try {
            var ex = getExternal();
            if (ex && ex.removeBind && ex.removeBind(bind.key) === "ok")
              loadBinds();
            else showMessage("Binds", "Could not remove this bind.");
          } catch (e) {
            showMessage("Binds", "Could not remove this bind.");
          }
        };
        actions.appendChild(edit);
        actions.appendChild(remove);
        row.appendChild(key);
        row.appendChild(command);
        row.appendChild(actions);
        bindList.appendChild(row);
      })(binds[bi]);
    }
  }

  function saveBind() {
    var key = (bindKeyInput.value || "").replace(/^\s+|\s+$/g, "");
    var command = (bindCommandInput.value || "").replace(/^\s+|\s+$/g, "");
    if (!key || !command) {
      showMessage("Binds", "Enter both a key and a command.");
      return;
    }
    try {
      var ex = getExternal();
      var result = ex && ex.saveBind ? ex.saveBind(key, command) : "error";
      if (result === "invalid_key") {
        showMessage(
          "Binds",
          "The key must not contain spaces, quotes, or semicolons."
        );
        return;
      }
      if (result === "invalid_command") {
        showMessage(
          "Binds",
          "The command must not contain quotes or line breaks."
        );
        return;
      }
      if (result !== "ok") {
        showMessage("Binds", "Could not save the binds file.");
        return;
      }
      bindKeyInput.value = "";
      bindCommandInput.value = "";
      loadBinds();
    } catch (e) {
      showMessage("Binds", "Could not save the binds file.");
    }
  }

  if (bindSaveBtn) bindSaveBtn.onclick = saveBind;
  if (bindCommandInput) {
    bindCommandInput.onkeydown = function (e) {
      if (e.key === "Enter" || e.keyCode === 13) saveBind();
    };
  }

  var diagnosticsResults = document.getElementById("diagnosticsResults");
  var diagnosticsRunBtn = document.getElementById("diagnosticsRunBtn");
  var diagnosticsState = document.getElementById("diagnosticsState");

  function runDiagnostics() {
    if (!diagnosticsResults) return;
    diagnosticsResults.innerHTML =
      '<div class="diagnostics-empty">Checking installation...</div>';
    if (diagnosticsRunBtn) {
      diagnosticsRunBtn.disabled = true;
      diagnosticsRunBtn.textContent = "Checking...";
    }
    if (diagnosticsState) diagnosticsState.textContent = "Running";
    window.setTimeout(function () {
      try {
        var ex = getExternal();
        if (!ex) throw new Error("Native launcher bridge is unavailable");
        var report = JSON.parse(ex.runDiagnostics() || "{}");
        diagnosticsResults.innerHTML = "";
        var paths = document.createElement("div");
        paths.className = "diagnostics-paths";
        paths.textContent =
          "Game: " +
          (report.gamePath || "Unknown") +
          " | Data: " +
          (report.appDataPath || "Unknown");
        diagnosticsResults.appendChild(paths);
        var checks = report.checks || [];
        var summary = [];
        for (var di = 0; di < checks.length; di++) {
          var check = checks[di];
          summary.push(
            (check.status === "ok"
              ? "PASS"
              : check.status === "error"
                ? "ERROR"
                : "WARNING") +
              "  " +
              (check.name || "Check") +
              "\n" +
              (check.details || "")
          );
          var item = document.createElement("div");
          item.className = "diagnostic-item " + (check.status || "warning");
          var marker = document.createElement("span");
          marker.className = "diagnostic-marker";
          marker.textContent =
            check.status === "ok" ? "OK" : check.status === "error" ? "!" : "?";
          var text = document.createElement("div");
          var name = document.createElement("div");
          name.className = "diagnostic-name";
          name.textContent = check.name || "Check";
          var details = document.createElement("div");
          details.className = "diagnostic-details";
          details.textContent = check.details || "";
          text.appendChild(name);
          text.appendChild(details);
          item.appendChild(marker);
          item.appendChild(text);
          diagnosticsResults.appendChild(item);
        }
        if (!checks.length)
          diagnosticsResults.innerHTML =
            '<div class="diagnostics-empty">No diagnostic results were returned.</div>';
        if (diagnosticsState) diagnosticsState.textContent = "Complete";
        showMessage(
          "Diagnostics Results",
          summary.length
            ? summary.join("\n\n")
            : "No diagnostic results were returned."
        );
      } catch (e) {
        diagnosticsResults.innerHTML =
          '<div class="diagnostics-empty">Diagnostics could not run.</div>';
        if (diagnosticsState) diagnosticsState.textContent = "Failed";
        showMessage(
          "Diagnostics",
          "The launcher could not run diagnostics. Make sure the executable and launcher data are from the same build."
        );
      } finally {
        if (diagnosticsRunBtn) {
          diagnosticsRunBtn.disabled = false;
          diagnosticsRunBtn.textContent = "Run Diagnostics";
        }
      }
    }, 0);
  }

  if (diagnosticsRunBtn) diagnosticsRunBtn.onclick = runDiagnostics;

  var diagnosticsRepairWorkshopBtn = document.getElementById(
    "diagnosticsRepairWorkshopBtn"
  );
  if (diagnosticsRepairWorkshopBtn) {
    diagnosticsRepairWorkshopBtn.onclick = function () {
      try {
        if (getExternal().repairWorkshopFolders() === "ok") {
          showMessage(
            "Diagnostics",
            "Workshop and profile folders were repaired."
          );
          runDiagnostics();
        } else {
          showMessage(
            "Diagnostics",
            "Some folders could not be created. Check folder permissions."
          );
        }
      } catch (e) {
        showMessage("Diagnostics", "Workshop folders could not be repaired.");
      }
    };
  }

  var diagnosticsVerifyBtn = document.getElementById("diagnosticsVerifyBtn");
  if (diagnosticsVerifyBtn) {
    diagnosticsVerifyBtn.onclick = function () {
      var verifyBtn = document.getElementById("verifyBtn");
      if (verifyBtn) verifyBtn.click();
    };
  }

  var diagnosticsClearProfileBtn = document.getElementById(
    "diagnosticsClearProfileBtn"
  );
  if (diagnosticsClearProfileBtn) {
    diagnosticsClearProfileBtn.onclick = function () {
      showConfirm(
        "Clear Profile Data",
        "Delete boiii_players? This removes saves, settings, and custom binds. A backup is saved first, so you can restore it from Profile Backups.",
        function () {
          try {
            var result = getExternal().clearProfileData();
            if (result === "game_running")
              showMessage(
                "Clear Profile Data",
                "Close the game before clearing profile data."
              );
            else if (result === "ok") {
              loadBinds();
              loadProfileBackups();
              showMessage(
                "Clear Profile Data",
                "Profile data was removed. New defaults will be created on next launch."
              );
              runDiagnostics();
            } else
              showMessage(
                "Clear Profile Data",
                "Profile data could not be removed."
              );
          } catch (e) {
            showMessage(
              "Clear Profile Data",
              "Profile data could not be removed."
            );
          }
        }
      );
    };
  }

  function addStorageRow(container, label, value, action) {
    var row = document.createElement("div");
    row.className = "storage-row";
    var name = document.createElement("div");
    name.className = "diagnostic-name";
    name.textContent = label;
    row.appendChild(name);
    var size = document.createElement("div");
    size.className = "diagnostic-details";
    size.textContent = value;
    row.appendChild(size);
    if (action) row.appendChild(action);
    container.appendChild(row);
  }

  var storageResults = document.getElementById("storageResults");
  function checkStorage() {
    if (!storageResults) return;
    storageResults.innerHTML =
      '<div class="diagnostics-empty">Checking storage...</div>';
    window.setTimeout(function () {
      try {
        var usage = JSON.parse(getExternal().getStorageUsage() || "{}");
        storageResults.innerHTML = "";
        addStorageRow(
          storageResults,
          "Crash reports",
          usage.crashCount +
            " files, " +
            usage.crashSize +
            " (" +
            usage.oldCrashCount +
            " older than 7 days, " +
            usage.oldCrashSize +
            ")"
        );
        addStorageRow(storageResults, "Logs", usage.logsSize);
        addStorageRow(storageResults, "Profile backups", usage.backupsSize);
        var items = usage.items || [];
        for (var si = 0; si < items.length; si++)
          addStorageRow(storageResults, items[si].name, items[si].size);
      } catch (e) {
        storageResults.innerHTML =
          '<div class="diagnostics-empty">Storage could not be checked.</div>';
      }
    }, 0);
  }

  var storageCheckBtn = document.getElementById("storageCheckBtn");
  if (storageCheckBtn) storageCheckBtn.onclick = checkStorage;

  var storageCleanBtn = document.getElementById("storageCleanBtn");
  if (storageCleanBtn) {
    storageCleanBtn.onclick = function () {
      showConfirm(
        "Delete Crash Reports",
        "Delete crash reports older than 7 days? Recent ones are kept in case you still need to send them.",
        function () {
          try {
            var parts = (getExternal().deleteOldCrashReports() || "0").split(
              " "
            );
            var count = parseInt(parts[0], 10) || 0;
            showMessage(
              "Delete Crash Reports",
              count
                ? "Deleted " +
                    count +
                    " crash reports, freeing " +
                    parts.slice(1).join(" ") +
                    "."
                : "There were no crash reports older than 7 days."
            );
            checkStorage();
          } catch (e) {
            showMessage(
              "Delete Crash Reports",
              "Crash reports could not be deleted."
            );
          }
        },
        "Delete"
      );
    };
  }

  var profileBackupList = document.getElementById("profileBackupList");
  function loadProfileBackups() {
    if (!profileBackupList) return;
    var backups = [];
    try {
      backups = JSON.parse(getExternal().listProfileBackups() || "[]");
    } catch (e) {}
    profileBackupList.innerHTML = "";
    if (!backups.length) {
      profileBackupList.innerHTML =
        '<div class="diagnostics-empty">No backups yet.</div>';
      return;
    }
    for (var bi = 0; bi < backups.length; bi++) {
      var restoreBtn = document.createElement("button");
      restoreBtn.type = "button";
      restoreBtn.className = "btn";
      restoreBtn.textContent = "Restore";
      restoreBtn.onclick = (function (file) {
        return function () {
          showConfirm(
            "Restore Profile",
            "Replace boiii_players with " +
              file +
              "? Your current profile is backed up first.",
            function () {
              var result = "error";
              try {
                result = getExternal().restoreProfileBackup(file);
              } catch (e) {}
              if (result === "game_running")
                showMessage(
                  "Restore Profile",
                  "Close the game before restoring a profile."
                );
              else if (result === "ok") {
                loadBinds();
                showMessage("Restore Profile", "Profile restored.");
              } else
                showMessage(
                  "Restore Profile",
                  "The profile could not be restored from this backup."
                );
              loadProfileBackups();
            },
            "Restore"
          );
        };
      })(backups[bi].file);
      addStorageRow(
        profileBackupList,
        backups[bi].file,
        backups[bi].size,
        restoreBtn
      );
    }
  }

  var profileBackupBtn = document.getElementById("profileBackupBtn");
  if (profileBackupBtn) {
    profileBackupBtn.onclick = function () {
      var file = "";
      try {
        file = getExternal().backUpProfile();
      } catch (e) {}
      showMessage(
        "Back Up Profile",
        file
          ? "Profile backed up to " + file + "."
          : "There is no profile data to back up yet."
      );
      loadProfileBackups();
    };
  }

  var profileBackupsFolderBtn = document.getElementById(
    "profileBackupsFolderBtn"
  );
  if (profileBackupsFolderBtn) {
    profileBackupsFolderBtn.onclick = function () {
      try {
        getExternal().openBackupsFolder();
      } catch (e) {}
    };
  }

  loadProfileBackups();

  var SETTINGS_DEFAULTS = {
    closeLauncher: true,
    autoUpdate: true,
    autoRefresh: true,
    reducedMotion: false,
    assetLimits: true,
    disableAssetPools: false,
    reduceStutter: false,
    skipIntro: false,
    skipAllIntros: false,
    friendsOnly: false,
    vsync: false,
    drawFps: false,
    smoothFramerate: false,
    unlockGfx: false,
    fullVram: false,
  };

  var ASSET_POOL_DEFAULTS = {
    ap_physpreset: 0x113,
    ap_physconstraints: 0x80,
    ap_destructibledef: 0x80,
    ap_xanim: 0x6270,
    ap_xmodel: 0x2c00,
    ap_xmodelmesh: 0x8c00,
    ap_material: 0x5800,
    ap_computeshaderset: 0x100,
    ap_techset: 0x400,
    ap_image: 0xc000,
    ap_sound: 0x20,
    ap_sound_patch: 0x10,
    ap_col_map: 0x2,
    ap_com_map: 0x2,
    ap_game_map: 0x2,
    ap_map_ents: 0x2,
    ap_gfx_map: 0x2,
    ap_lightdef: 0x20,
    ap_lensflaredef: 0x46,
    ap_ui_map: 0x00,
    ap_font: 0x10,
    ap_fonticon: 0x10,
    ap_localize: 0x6400,
    ap_weapon: 0x600,
    ap_weapondef: 0x00,
    ap_weaponvariant: 0x00,
    ap_weaponfull: 0x00,
    ap_cgmediatable: 0x5,
    ap_playersoundstable: 0x10,
    ap_playerfxtable: 0x10,
    ap_sharedweaponsounds: 0x40,
    ap_attachment: 0x80,
    ap_attachmentunique: 0x864,
    ap_weaponcamo: 0x200,
    ap_customizationtable: 0x8,
    ap_customizationtable_feimages: 0x8,
    ap_customizationtablecolor: 0x400,
    ap_snddriverglobals: 0x1,
    ap_fx: 0x7d0,
    ap_tagfx: 0x40,
    ap_klf: 0x46,
    ap_impactsfxtable: 0x100,
    ap_impactsoundstable: 0x40,
    ap_player_character: 0x8,
    ap_aitype: 0x60,
    ap_character: 0x96,
    ap_xmodelalias: 0x30,
    ap_rawfile: 0x1388,
    ap_stringtable: 0xdc,
    ap_structuredtable: 0x69,
    ap_leaderboarddef: 0x100,
    ap_ddl: 0x40,
    ap_glasses: 0x2,
    ap_texturelist: 0x8,
    ap_scriptparsetree: 0x47e,
    ap_keyvaluepairs: 0x40,
    ap_vehicle: 0x40,
    ap_addon_map_ents: 0x1,
    ap_tracer: 0x64,
    ap_slug: 0x5,
    ap_surfacefxtable: 0x40,
    ap_surfacesounddef: 0x100,
    ap_footsteptable: 0x20,
    ap_entityfximpacts: 0x100,
    ap_entitysoundimpacts: 0x100,
    ap_zbarrier: 0x10,
    ap_vehiclefxdef: 0x20,
    ap_vehiclesounddef: 0x20,
    ap_typeinfo: 0x00,
    ap_scriptbundle: 0x400,
    ap_scriptbundlelist: 0x40,
    ap_rumble: 0x118,
    ap_bulletpenetration: 0x1,
    ap_locdmgtable: 0x1,
    ap_aimtable: 0xc,
    ap_animselectortable: 0x40,
    ap_animmappingtable: 0x40,
    ap_animstatemachine: 0x40,
    ap_behaviortree: 0x40,
    ap_behaviorstatemachine: 0x80,
    ap_ttf: 0x30,
    ap_sanim: 0x400,
    ap_lightdescription: 0x226,
    ap_shellshock: 0x40,
    ap_xcam: 0x214,
    ap_bgcache: 0x20,
    ap_texturecombo: 0x10,
    ap_flametable: 0x10,
    ap_bitfield: 0x34,
    ap_attachmentcosmeticvariant: 0x280,
    ap_maptable: 0x19,
    ap_maptableloadingimages: 0x19,
    ap_medal: 0x300,
    ap_medaltable: 0x20,
    ap_objective: 0x100,
    ap_objectivelist: 0x40,
    ap_umbra_tome: 0x00,
    ap_navmesh: 0x2,
    ap_navvolume: 0x2,
    ap_binaryhtml: 0x800,
    ap_laser: 0x32,
    ap_beam: 0x32,
    ap_streamerhint: 0x32,
  };

  function loadAllSettings() {
    var settings = {};
    try {
      var stored = localStorage.getItem("boiii_settings");
      if (stored) settings = JSON.parse(stored);
    } catch (e) {}
    try {
      var ex = getExternal();
      var nativeSettings =
        ex && ex.readLauncherSettings ? ex.readLauncherSettings() : "";
      if (nativeSettings) settings = JSON.parse(nativeSettings);
    } catch (e) {}
    var merged = {};
    for (var k in SETTINGS_DEFAULTS) {
      merged[k] = settings.hasOwnProperty(k)
        ? settings[k]
        : SETTINGS_DEFAULTS[k];
    }
    return merged;
  }

  function saveAllSettings(settings) {
    var data = JSON.stringify(settings);
    try {
      localStorage.setItem("boiii_settings", data);
    } catch (e) {}
    try {
      var ex = getExternal();
      if (ex && ex.saveLauncherSettings) ex.saveLauncherSettings(data);
    } catch (e) {}
  }

  function getSetting(key) {
    var s = loadAllSettings();
    return s.hasOwnProperty(key) ? s[key] : SETTINGS_DEFAULTS[key];
  }

  function setSetting(key, value) {
    var s = loadAllSettings();
    s[key] = value;
    saveAllSettings(s);
  }

  function applySettingsToUI() {
    var s = loadAllSettings();
    if (document.body) {
      if (s.reducedMotion) document.body.classList.add("reduced-motion");
      else document.body.classList.remove("reduced-motion");
    }
    var allToggles = document.querySelectorAll(
      ".settings-toggle[data-setting]"
    );
    for (var i = 0; i < allToggles.length; i++) {
      var key = allToggles[i].getAttribute("data-setting");
      if (s[key]) {
        allToggles[i].classList.add("active");
      } else {
        allToggles[i].classList.remove("active");
      }
    }
  }

  var allSettingToggles = document.querySelectorAll(
    ".settings-toggle[data-setting]"
  );
  for (var ti = 0; ti < allSettingToggles.length; ti++) {
    (function (toggle) {
      toggle.onclick = function () {
        toggle.classList.toggle("active");
        var key = toggle.getAttribute("data-setting");
        var isActive = toggle.classList.contains("active");
        setSetting(key, isActive);
        onSettingChanged(key, isActive);
      };
    })(allSettingToggles[ti]);
  }

  function onSettingChanged(key, value) {
    if (key === "reducedMotion" && document.body) {
      if (value) document.body.classList.add("reduced-motion");
      else document.body.classList.remove("reduced-motion");
    }
    try {
      var ex = getExternal();
      if (!ex) return;
      if (key === "reduceStutter" && ex.toggleReduceStutter) {
        ex.toggleReduceStutter(value ? "1" : "0");
      } else if (key === "skipIntro" && ex.toggleSkipIntro) {
        ex.toggleSkipIntro(value ? "1" : "0");
      } else if (key === "skipAllIntros" && ex.toggleSkipAllIntros) {
        ex.toggleSkipAllIntros(value ? "1" : "0");
        if (value) {
          setSetting("skipIntro", true);
          var siToggle = document.getElementById("settingsSkipIntro");
          if (siToggle) siToggle.classList.add("active");
        }
      } else if (key === "friendsOnly" && ex.setGameSetting) {
        ex.setGameSetting("friendsOnly", value ? "1" : "0");
      } else if (key === "vsync" && ex.setGameSetting) {
        ex.setGameSetting("Vsync", value ? "1" : "0");
      } else if (key === "drawFps" && ex.setGameSetting) {
        ex.setGameSetting("DrawFPS", value ? "1" : "0");
      } else if (key === "smoothFramerate" && ex.setGameSetting) {
        ex.setGameSetting("SmoothFramerate", value ? "1" : "0");
      } else if (key === "unlockGfx" && ex.setGameSetting) {
        ex.setGameSetting("RestrictGraphicsOptions", value ? "0" : "1");
      } else if (key === "fullVram" && ex.setGameSetting) {
        if (value) {
          ex.setGameSetting("VideoMemory", "1");
          ex.setGameSetting("StreamMinResident", "0");
        } else {
          ex.setGameSetting("VideoMemory", "0.75");
          ex.setGameSetting("StreamMinResident", "1");
        }
      } else if (key === "assetLimits") {
        if (ex.setGameSetting)
          ex.setGameSetting("asset_limits_enabled", value ? "1" : "0");
      } else if (key === "disableAssetPools") {
        var fieldset = document.getElementById("assetPoolsFieldset");
        if (fieldset) {
          if (value) {
            fieldset.classList.add("disabled");
          } else {
            fieldset.classList.remove("disabled");
          }
        }
        if (ex.setGameSetting) {
          ex.setGameSetting("disable_asset_pools", value ? "1" : "0");
        }
      }
    } catch (e) {}
  }

  applySettingsToUI();

  function setupSettingsInput(inputId, configKey) {
    var input = document.getElementById(inputId);
    if (!input) return;
    input.onchange = function () {
      var val = input.value.replace(/^\s+|\s+$/g, "");
      if (!val) return;
      try {
        var ex = getExternal();
        if (ex && ex.setGameSetting) ex.setGameSetting(configKey, val);
      } catch (e) {}
    };
  }

  setupSettingsInput("settingsResolution", "WindowSize");
  setupSettingsInput("settingsRefreshRate", "RefreshRate");
  setupSettingsInput("settingsFpsLimit", "MaxFPS");
  setupSettingsInput("settingsFov", "FOV");
  setupSettingsInput("settingsMaxLatency", "MaxFrameLatency");

  var displayModeSelect = document.getElementById("settingsDisplayMode");
  if (displayModeSelect) {
    displayModeSelect.onchange = function () {
      try {
        var ex = getExternal();
        if (ex && ex.setGameSetting)
          ex.setGameSetting("FullScreenMode", displayModeSelect.value);
      } catch (e) {}
    };
  }

  var networkPwInput = document.getElementById("settingsNetworkPassword");
  if (networkPwInput) {
    networkPwInput.onchange = function () {
      try {
        var ex = getExternal();
        if (ex && ex.setGameSetting)
          ex.setGameSetting("networkpassword", networkPwInput.value);
      } catch (e) {}
    };
  }

  var netPasswordInput = document.getElementById("settingsNetPassword");
  if (netPasswordInput) {
    netPasswordInput.onchange = function () {
      try {
        var ex = getExternal();
        if (ex && ex.setGameSetting)
          ex.setGameSetting("netpassword", netPasswordInput.value);
      } catch (e) {}
    };
  }

  var workshopRetryInput = document.getElementById("settingsWorkshopRetry");
  if (workshopRetryInput) {
    workshopRetryInput.onchange = function () {
      try {
        var val = parseInt(workshopRetryInput.value, 10);
        if (isNaN(val) || val < 1) val = 1;
        if (val > 1000) val = 1000;
        workshopRetryInput.value = val;
        var ex = getExternal();
        if (ex && ex.setGameSetting)
          ex.setGameSetting("workshop_retry_attempts", String(val));
      } catch (e) {}
    };
  }

  var workshopTimeoutInput = document.getElementById("settingsWorkshopTimeout");
  if (workshopTimeoutInput) {
    workshopTimeoutInput.onchange = function () {
      try {
        var val = parseInt(workshopTimeoutInput.value, 10);
        if (isNaN(val) || val < 60) val = 60;
        if (val > 3600) val = 3600;
        workshopTimeoutInput.value = val;
        var ex = getExternal();
        if (ex && ex.setGameSetting)
          ex.setGameSetting("workshop_timeout", String(val));
      } catch (e) {}
    };
  }

  // Asset pool input handlers
  var allPoolInputs = document.querySelectorAll(".asset-pool-input");
  for (var pi = 0; pi < allPoolInputs.length; pi++) {
    (function (input) {
      input.onchange = function () {
        try {
          var val = parseInt(input.value, 10);
          var minVal = parseInt(input.getAttribute("min"), 10) || 64;
          var poolKey = input.getAttribute("data-pool");
          if (isNaN(val) || val < minVal) val = minVal;
          if (val > 65536) val = 65536;
          input.value = val;
          var ex = getExternal();
          if (ex && ex.setGameSetting) ex.setGameSetting(poolKey, String(val));
        } catch (e) {}
      };
    })(allPoolInputs[pi]);
  }

  // Apply initial disable state for asset pools fieldset
  (function () {
    var disabled = getSetting("disableAssetPools");
    var fieldset = document.getElementById("assetPoolsFieldset");
    if (fieldset && disabled) fieldset.classList.add("disabled");
  })();

  var applyPresetBtn = document.getElementById("settingsApplyPresetBtn");
  if (applyPresetBtn) {
    applyPresetBtn.onclick = function () {
      var presetSelect = document.getElementById("settingsGraphicsPreset");
      if (!presetSelect || !presetSelect.value) return;
      try {
        var ex = getExternal();
        if (ex && ex.applyGraphicsPreset) {
          var result = ex.applyGraphicsPreset(presetSelect.value);
          if (result === "ok") {
            showMessage(
              "Preset Applied",
              "Graphics preset applied successfully. Restart the game for changes to take effect."
            );
            loadGameSettings();
          } else {
            showMessage("Error", "Failed to apply preset: " + result);
          }
        }
      } catch (e) {}
    };
  }

  function loadGameSettings() {
    try {
      var ex = getExternal();
      if (!ex || !ex.getGameSettings) return;
      var json = ex.getGameSettings();
      if (!json) return;
      var s = typeof json === "string" ? JSON.parse(json) : json;
      if (!s) return;

      if (s.FullScreenMode !== undefined && displayModeSelect)
        displayModeSelect.value = String(s.FullScreenMode);
      if (s.WindowSize !== undefined) {
        var el = document.getElementById("settingsResolution");
        if (el) el.value = s.WindowSize;
      }
      if (s.RefreshRate !== undefined) {
        var el = document.getElementById("settingsRefreshRate");
        if (el) el.value = s.RefreshRate;
      }
      if (s.Vsync !== undefined) {
        setSetting("vsync", s.Vsync === "1" || s.Vsync === 1);
        var vt = document.getElementById("settingsVsync");
        if (vt) {
          if (s.Vsync === "1" || s.Vsync === 1) vt.classList.add("active");
          else vt.classList.remove("active");
        }
      }

      if (s.MaxFPS !== undefined) {
        var el = document.getElementById("settingsFpsLimit");
        if (el) el.value = s.MaxFPS;
      }
      if (s.FOV !== undefined) {
        var el = document.getElementById("settingsFov");
        if (el) el.value = s.FOV;
      }
      if (s.DrawFPS !== undefined) {
        setSetting("drawFps", s.DrawFPS === "1" || s.DrawFPS === 1);
        var dt = document.getElementById("settingsDrawFps");
        if (dt) {
          if (s.DrawFPS === "1" || s.DrawFPS === 1) dt.classList.add("active");
          else dt.classList.remove("active");
        }
      }
      if (s.SmoothFramerate !== undefined) {
        setSetting(
          "smoothFramerate",
          s.SmoothFramerate === "1" || s.SmoothFramerate === 1
        );
        var sf = document.getElementById("settingsSmoothFramerate");
        if (sf) {
          if (s.SmoothFramerate === "1" || s.SmoothFramerate === 1)
            sf.classList.add("active");
          else sf.classList.remove("active");
        }
      }

      if (s.RestrictGraphicsOptions !== undefined) {
        var unlocked =
          s.RestrictGraphicsOptions === "0" || s.RestrictGraphicsOptions === 0;
        setSetting("unlockGfx", unlocked);
        var ut = document.getElementById("settingsUnlockGfx");
        if (ut) {
          if (unlocked) ut.classList.add("active");
          else ut.classList.remove("active");
        }
      }
      if (s.MaxFrameLatency !== undefined) {
        var el = document.getElementById("settingsMaxLatency");
        if (el) el.value = s.MaxFrameLatency;
      }
      if (s.VideoMemory !== undefined) {
        var fv =
          (s.VideoMemory === "1" || s.VideoMemory === 1) &&
          (s.StreamMinResident === "0" || s.StreamMinResident === 0);
        setSetting("fullVram", fv);
        var ft = document.getElementById("settingsFullVram");
        if (ft) {
          if (fv) ft.classList.add("active");
          else ft.classList.remove("active");
        }
      }

      if (s.networkpassword !== undefined && networkPwInput)
        networkPwInput.value = s.networkpassword;
      if (s.netpassword !== undefined && netPasswordInput)
        netPasswordInput.value = s.netpassword;
      if (s.friendsOnly !== undefined) {
        var fo =
          s.friendsOnly === "1" ||
          s.friendsOnly === 1 ||
          s.friendsOnly === true;
        setSetting("friendsOnly", fo);
        var ft2 = document.getElementById("settingsFriendsOnly");
        if (ft2) {
          if (fo) ft2.classList.add("active");
          else ft2.classList.remove("active");
        }
      }

      if (s.reduceStutter !== undefined) {
        setSetting(
          "reduceStutter",
          s.reduceStutter === true || s.reduceStutter === "1"
        );
        var rst = document.getElementById("settingsReduceStutter");
        if (rst) {
          if (s.reduceStutter === true || s.reduceStutter === "1")
            rst.classList.add("active");
          else rst.classList.remove("active");
        }
      }
      if (s.skipIntro !== undefined) {
        setSetting("skipIntro", s.skipIntro === true || s.skipIntro === "1");
        var sit = document.getElementById("settingsSkipIntro");
        if (sit) {
          if (s.skipIntro === true || s.skipIntro === "1")
            sit.classList.add("active");
          else sit.classList.remove("active");
        }
      }
      if (s.skipAllIntros !== undefined) {
        setSetting(
          "skipAllIntros",
          s.skipAllIntros === true || s.skipAllIntros === "1"
        );
        var sat = document.getElementById("settingsSkipAllIntros");
        if (sat) {
          if (s.skipAllIntros === true || s.skipAllIntros === "1")
            sat.classList.add("active");
          else sat.classList.remove("active");
        }
      }

      if (s.assetLimits !== undefined) {
        var al =
          s.assetLimits === "1" ||
          s.assetLimits === 1 ||
          s.assetLimits === true;
        setSetting("assetLimits", al);
        var alt = document.getElementById("settingsAssetLimits");
        if (alt) {
          if (al) alt.classList.add("active");
          else alt.classList.remove("active");
        }
      }

      if (s.disable_asset_pools !== undefined) {
        var dap =
          s.disable_asset_pools === "1" ||
          s.disable_asset_pools === 1 ||
          s.disable_asset_pools === true;
        setSetting("disableAssetPools", dap);
        var dapt = document.getElementById("settingsDisableAssetPools");
        if (dapt) {
          if (dap) dapt.classList.add("active");
          else dapt.classList.remove("active");
        }
        var fieldset = document.getElementById("assetPoolsFieldset");
        if (fieldset) {
          if (dap) fieldset.classList.add("disabled");
          else fieldset.classList.remove("disabled");
        }
      }

      for (var poolKey in ASSET_POOL_DEFAULTS) {
        if (s[poolKey] !== undefined) {
          var poolInputs = document.querySelectorAll(
            '.asset-pool-input[data-pool="' + poolKey + '"]'
          );
          for (var pii = 0; pii < poolInputs.length; pii++) {
            poolInputs[pii].value = s[poolKey];
          }
        }
      }

      if (s.workshop_retry_attempts !== undefined) {
        var wri = document.getElementById("settingsWorkshopRetry");
        if (wri) wri.value = s.workshop_retry_attempts;
      }
      if (s.workshop_timeout !== undefined) {
        var wti = document.getElementById("settingsWorkshopTimeout");
        if (wti) wti.value = s.workshop_timeout;
      }
    } catch (e) {}
  }

  loadGameSettings();

  var resetBtn = document.getElementById("settingsResetBtn");
  if (resetBtn) {
    resetBtn.onclick = function () {
      showConfirm(
        "Reset Settings",
        "Are you sure you want to reset all settings to defaults? This cannot be undone.",
        function () {
          try {
            var ex = getExternal();
            // Revert file-backed toggles
            if (ex) {
              if (ex.toggleReduceStutter) ex.toggleReduceStutter("0");
              if (ex.toggleSkipIntro) ex.toggleSkipIntro("0");
              if (ex.toggleSkipAllIntros) ex.toggleSkipAllIntros("0");
              if (ex.setGameSetting) {
                ex.setGameSetting("asset_limits_enabled", "1");
                ex.setGameSetting("disable_asset_pools", "0");
                ex.setGameSetting("friendsOnly", "0");
                ex.setGameSetting("networkpassword", "");
                ex.setGameSetting("netpassword", "");
                ex.setGameSetting("workshop_retry_attempts", "30");
                ex.setGameSetting("workshop_timeout", "300");
                // Reset all pool sizes to defaults
                for (var pk in ASSET_POOL_DEFAULTS) {
                  ex.setGameSetting(pk, String(ASSET_POOL_DEFAULTS[pk]));
                }
              }
            }
          } catch (e) {}
          try {
            localStorage.removeItem("boiii_settings");
          } catch (e) {}
          for (var k in SETTINGS_DEFAULTS) {
            setSetting(k, SETTINGS_DEFAULTS[k]);
          }
          applySettingsToUI();
          if (networkPwInput) networkPwInput.value = "";
          if (netPasswordInput) netPasswordInput.value = "";
          loadGameSettings();
          showMessage(
            "Settings Reset",
            "All settings have been reset to defaults. Restart the game for changes to take effect."
          );
        }
      );
    };
  }

  var assetPoolsResetBtn = document.getElementById("assetPoolsResetBtn");
  if (assetPoolsResetBtn) {
    assetPoolsResetBtn.onclick = function () {
      showConfirm(
        "Reset Asset Pools",
        "Reset all asset pool sizes to their default values?",
        function () {
          try {
            var ex = getExternal();
            var inputs = document.querySelectorAll(".asset-pool-input");
            for (var ri = 0; ri < inputs.length; ri++) {
              var poolKey = inputs[ri].getAttribute("data-pool");
              var defVal = ASSET_POOL_DEFAULTS[poolKey];
              if (defVal !== undefined) {
                inputs[ri].value = defVal;
                if (ex && ex.setGameSetting)
                  ex.setGameSetting(poolKey, String(defVal));
              }
            }
          } catch (e) {}
          showMessage(
            "Asset Pools Reset",
            "All asset pool sizes have been reset to defaults. Restart the game for changes to take effect."
          );
        }
      );
    };
  }

  var workshopProgressFolder = document.getElementById(
    "workshopProgressFolder"
  );
  if (workshopProgressFolder) {
    workshopProgressFolder.onclick = function () {
      if (_workshopDownloadFolder && _workshopDownloadFolder.length > 0) {
        try {
          getExternal().openUrl(_workshopDownloadFolder);
        } catch (e) {}
      }
    };
  }

  refreshModsGrid();

  var _friendsData = [];

  function loadFriendIdentity() {
    try {
      var ex = getExternal();
      if (!ex || !ex.readFriendIdentity) return;
      var identity = JSON.parse(ex.readFriendIdentity() || "{}");
      var code = identity.friend_code ? String(identity.friend_code) : "";
      var nameEl = document.getElementById("friendIdentityName");
      var codeEl = document.getElementById("friendIdentityCode");
      var copyBtn = document.getElementById("friendCodeCopyBtn");
      if (nameEl && identity.name) nameEl.textContent = identity.name;
      if (codeEl) codeEl.textContent = code || "Unavailable";
      if (copyBtn) {
        copyBtn.disabled = !code;
        copyBtn.setAttribute("data-code", code);
      }
    } catch (e) {}
  }

  function loadFriendsList() {
    try {
      var ex = getExternal();
      if (ex && ex.readFriends) {
        var raw = ex.readFriends();
        if (raw && typeof raw === "string" && raw.length > 0) {
          _friendsData = JSON.parse(raw);
          if (!Array.isArray(_friendsData)) _friendsData = [];
        } else {
          _friendsData = [];
        }
      }
    } catch (e) {
      _friendsData = [];
    }
    renderFriendsList();
  }

  function renderFriendsList() {
    var list = document.getElementById("friendsList");
    var countEl = document.getElementById("friendsCount");
    if (!list) return;
    if (countEl)
      countEl.textContent =
        _friendsData.length +
        " friend" +
        (_friendsData.length !== 1 ? "s" : "");

    if (_friendsData.length === 0) {
      list.innerHTML =
        '<div class="friends-empty"><div class="friends-empty-icon">&#128100;</div><div class="friends-empty-text">No friends added yet</div></div>';
      return;
    }

    var html = "";
    for (var i = 0; i < _friendsData.length; i++) {
      var f = _friendsData[i];
      var sid = f.steam_id !== undefined ? String(f.steam_id) : "";
      var nm = f.name || "Unknown";
      html += '<div class="friend-item" data-steamid="' + sid + '">';
      html += '<div class="friend-icon">&#128100;</div>';
      html += '<div class="friend-info">';
      html +=
        '<div class="friend-name">' +
        nm.replace(/</g, "&lt;").replace(/>/g, "&gt;") +
        "</div>";
      html += '<div class="friend-steamid">' + sid + "</div>";
      html += "</div>";
      html +=
        '<button type="button" class="friend-remove-btn" data-remove-sid="' +
        sid +
        '" title="Remove">&times;</button>';
      html += "</div>";
    }
    list.innerHTML = html;

    var removeBtns = list.querySelectorAll(".friend-remove-btn");
    for (var ri = 0; ri < removeBtns.length; ri++) {
      (function (btn) {
        btn.onclick = function () {
          var sid = btn.getAttribute("data-remove-sid");
          if (!sid) return;
          try {
            var ex = getExternal();
            if (ex && ex.removeFriend) {
              ex.removeFriend(sid);
            }
          } catch (e) {}
          _friendsData = _friendsData.filter(function (f) {
            return String(f.steam_id) !== sid;
          });
          renderFriendsList();
        };
      })(removeBtns[ri]);
    }
  }

  var friendAddBtn = document.getElementById("friendAddBtn");
  if (friendAddBtn) {
    friendAddBtn.onclick = function () {
      var nameInput = document.getElementById("friendNameInput");
      var sidInput = document.getElementById("friendCodeInput");
      if (!nameInput || !sidInput) return;

      var name = nameInput.value.replace(/^\s+|\s+$/g, "");
      var sid = sidInput.value.replace(/^\s+|\s+$/g, "");

      if (!name || !sid) {
        showMessage(
          "Add Friend",
          "Please enter both a display name and a BOIII Friend Code."
        );
        return;
      }
      if (!/^\d{5,20}$/.test(sid)) {
        showMessage("Add Friend", "BOIII Friend Code must be a numeric value.");
        return;
      }

      try {
        var ex = getExternal();
        if (ex && ex.addFriend) {
          var result = ex.addFriend(sid, name);
          if (result === "duplicate") {
            showMessage(
              "Add Friend",
              "This BOIII Friend Code is already in your friends list."
            );
            return;
          } else if (result === "error") {
            showMessage(
              "Add Friend",
              "Failed to add friend. Please check the inputs."
            );
            return;
          }
        }
      } catch (e) {
        showMessage("Add Friend", "An error occurred while adding the friend.");
        return;
      }

      nameInput.value = "";
      sidInput.value = "";
      loadFriendsList();
    };
  }

  var friendCodeCopyBtn = document.getElementById("friendCodeCopyBtn");
  if (friendCodeCopyBtn) {
    friendCodeCopyBtn.onclick = function () {
      var code = friendCodeCopyBtn.getAttribute("data-code") || "";
      if (!code) return;
      try {
        if (window.clipboardData) window.clipboardData.setData("Text", code);
        else if (navigator.clipboard) navigator.clipboard.writeText(code);
      } catch (e) {}
    };
  }

  var origSetPage = setPage;
  setPage = function (targetPage) {
    origSetPage(targetPage);
    if (targetPage === "friends") {
      loadFriendsList();
    }
  };

  loadFriendsList();
  loadFriendIdentity();
  setInterval(function () {
    if (activePage === "friends" && !document.hidden) {
      loadFriendsList();
      loadFriendIdentity();
    }
  }, 5000);

  function versionTagFromStored(value) {
    if (!value) return value;
    if (value.indexOf("ezz:") === 0) return value;
    var tag = value;
    if (tag.indexOf("boiii-") === 0) tag = tag.substring("boiii-".length);
    if (tag.slice(-4) === ".exe") tag = tag.slice(0, -4);
    return tag;
  }

  function isCreatorVersion(value) {
    return typeof value === "string" && value.indexOf("ezz:") === 0;
  }

  function versionLabel(value) {
    if (value === "latest") return getLatestLabel();
    if (isCreatorVersion(value))
      return "Ezz " + value.substring("ezz:".length) + " (original build)";
    return value;
  }

  function setVersionDisplayStyle(value) {
    if (!verDropDisplay) return;
    var external = isCreatorVersion(value);
    verDropDisplay.className =
      "version-selector-display" + (external ? " external" : "");
    verDropDisplay.title = external
      ? "An original Ezz build, not a CodHQ build: none of our fixes or branding apply."
      : value === "latest"
        ? "Always the newest CodHQ build; the client updates itself on launch."
        : "This CodHQ build keeps its executable; the client's data files still update.";
  }

  function selectVersion(value, label) {
    _selectedVersion = value;
    if (verDropText) verDropText.textContent = label;
    setVersionDisplayStyle(value);
    if (versionOptions) {
      var opts = versionOptions.querySelectorAll(".version-selector-option");
      for (var i = 0; i < opts.length; i++) {
        if (opts[i].getAttribute("data-value") === value) {
          opts[i].className = "version-selector-option selected";
        } else {
          opts[i].className = "version-selector-option";
        }
      }
    }
    if (versionDropdown)
      versionDropdown.className = "version-selector-container";

    try {
      var ex = getExternal();
      if (ex && ex.setSelectedVersion) {
        ex.setSelectedVersion(value);
      }
    } catch (e) {}
  }

  function addVersionOption(value, label, prepend) {
    if (!versionOptions) return;
    var div = document.createElement("div");
    div.className = "version-selector-option";
    div.setAttribute("data-value", value);
    div.textContent = label;
    div.onclick = function () {
      selectVersion(value, label);
    };
    if (prepend && versionOptions.firstChild) {
      versionOptions.insertBefore(div, versionOptions.firstChild);
    } else {
      versionOptions.appendChild(div);
    }
  }

  if (verDropDisplay) {
    verDropDisplay.onclick = function () {
      if (!versionDropdown) return;
      if (versionDropdown.className.indexOf("open") !== -1) {
        versionDropdown.className = "version-selector-container";
      } else {
        versionDropdown.className = "version-selector-container open";
      }
    };
  }

  function getLatestLabel() {
    return _latestVersionTag
      ? _latestVersionTag + " (Latest, auto-update)"
      : "Latest (auto-update)";
  }

  if (versionOptions) {
    var defaultOpt = versionOptions.querySelector(".version-selector-option");
    if (defaultOpt) {
      defaultOpt.onclick = function () {
        selectVersion("latest", getLatestLabel());
      };
    }
  }

  document.addEventListener("click", function (e) {
    if (versionDropdown && versionDropdown.className.indexOf("open") !== -1) {
      var target = e.target || e.srcElement;
      var inside = false;
      while (target) {
        if (target === versionDropdown) {
          inside = true;
          break;
        }
        target = target.parentNode;
      }
      if (!inside) {
        versionDropdown.className = "version-selector-container";
      }
    }
  });

  try {
    var storedVersion =
      getExternal() &&
      getExternal().getSelectedVersion &&
      getExternal().getSelectedVersion();
    if (storedVersion) {
      _selectedVersion = versionTagFromStored(storedVersion) || "latest";
      selectVersion(_selectedVersion, versionLabel(_selectedVersion));
    }
  } catch (e) {}

  var CODHQ_SITE = "https://larkthestar.github.io/codhq-boiii/";
  var CREATOR_RELEASES_API =
    "https://api.github.com/repos/Ezz-lol/boiii-free/releases?per_page=30";

  function applySelectedVersionLabel() {
    var value = _selectedVersion || "latest";
    selectVersion(value, versionLabel(value));
  }

  // Our versions come from our own site: versions.json lists the GitHub releases
  // this repository publishes, so the selector can only ever name CodHQ builds.
  function fetchVersions() {
    if (!versionOptions) return;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", CODHQ_SITE + "versions.json?" + Date.now(), true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status !== 200) {
        console.warn("CodHQ version list unavailable:", xhr.status);
        applySelectedVersionLabel();
        return;
      }
      var versions = [];
      try {
        versions = JSON.parse(xhr.responseText) || [];
      } catch (e) {
        console.error("Error parsing versions.json:", e);
      }
      if (!Array.isArray(versions) || !versions.length) {
        applySelectedVersionLabel();
        return;
      }
      _latestVersionTag = versions[0].tag || "";
      var latestOption = versionOptions.querySelector(
        '.version-selector-option[data-value="latest"]'
      );
      if (latestOption) latestOption.textContent = getLatestLabel();
      for (var i = 1; i < versions.length; i++) {
        var entry = versions[i] || {};
        if (!entry.tag || !entry.url) continue;
        _versionsData[entry.tag] = {
          url: entry.url,
          name: "versions/boiii-" + entry.tag + ".exe",
        };
        addVersionOption(entry.tag, entry.tag);
      }
      applySelectedVersionLabel();
    };
    xhr.send();
  }

  var creatorBuildsPopup = document.getElementById("creatorBuilds");
  var creatorBuildsList = document.getElementById("ezzVersionOptions");
  var creatorBuildsLoaded = false;

  function showCreatorBuildsStatus(text) {
    if (!creatorBuildsList) return;
    creatorBuildsList.innerHTML = "";
    var status = document.createElement("div");
    status.className = "creator-builds-status";
    status.textContent = text;
    creatorBuildsList.appendChild(status);
  }

  function formatMegabytes(bytes) {
    if (!bytes) return "";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

  function addCreatorBuild(entry) {
    var row = document.createElement("div");
    row.className = "creator-build-row";

    var info = document.createElement("div");
    info.className = "creator-build-info";
    var tag = document.createElement("div");
    tag.className = "creator-build-tag";
    tag.textContent = entry.tag;
    var meta = document.createElement("div");
    meta.className = "creator-build-meta";
    meta.textContent =
      (entry.size ? formatMegabytes(entry.size) + " \u00b7 " : "") +
      "from Ezz's GitHub";
    info.appendChild(tag);
    info.appendChild(meta);

    var use = document.createElement("button");
    use.type = "button";
    use.className = "btn creator-build-use";
    use.textContent = "Use";
    use.onclick = function () {
      var value = "ezz:" + entry.tag;
      _versionsData[value] = {
        url: entry.url,
        name: "versions/boiii-ezz-" + entry.tag + ".exe",
      };
      selectVersion(value, versionLabel(value));
      closeCreatorBuilds();
    };

    row.appendChild(info);
    row.appendChild(use);
    creatorBuildsList.appendChild(row);
  }

  // Ezz's own releases, listed apart from the CodHQ selector on purpose.
  function fetchCreatorBuilds() {
    if (!creatorBuildsList || creatorBuildsLoaded) return;
    showCreatorBuildsStatus("Loading Ezz's releases\u2026");
    var xhr = new XMLHttpRequest();
    xhr.open("GET", CREATOR_RELEASES_API + "&_" + Date.now(), true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status !== 200) {
        showCreatorBuildsStatus(
          "Ezz's release list could not be loaded (" + xhr.status + ")."
        );
        return;
      }
      var releases = [];
      try {
        releases = JSON.parse(xhr.responseText) || [];
      } catch (e) {
        console.error("Error parsing Ezz's releases:", e);
      }
      creatorBuildsList.innerHTML = "";
      var shown = 0;
      for (var i = 0; i < releases.length; i++) {
        var release = releases[i] || {};
        var assets = release.assets || [];
        var asset = null;
        for (var j = 0; j < assets.length; j++) {
          if (assets[j] && assets[j].name === "boiii.exe") {
            asset = assets[j];
            break;
          }
        }
        if (!asset || !release.tag_name) continue;
        addCreatorBuild({
          tag: release.tag_name,
          url: asset.browser_download_url,
          size: asset.size,
        });
        shown++;
      }
      if (!shown) {
        showCreatorBuildsStatus(
          "Ezz's GitHub has no release with a boiii.exe download right now."
        );
        return;
      }
      creatorBuildsLoaded = true;
    };
    xhr.send();
  }

  function openCreatorBuilds() {
    if (!creatorBuildsPopup) return;
    creatorBuildsPopup.classList.add("active");
    fetchCreatorBuilds();
  }

  function closeCreatorBuilds() {
    if (creatorBuildsPopup) creatorBuildsPopup.classList.remove("active");
  }

  var creatorBuildsBtn = document.getElementById("creatorBuildsBtn");
  if (creatorBuildsBtn) creatorBuildsBtn.onclick = openCreatorBuilds;
  var creatorBuildsClose = document.getElementById("creatorBuildsClose");
  if (creatorBuildsClose) creatorBuildsClose.onclick = closeCreatorBuilds;
  var creatorBuildsBack = document.getElementById("creatorBuildsBack");
  if (creatorBuildsBack) {
    creatorBuildsBack.onclick = function () {
      selectVersion("latest", getLatestLabel());
      closeCreatorBuilds();
    };
  }
  if (creatorBuildsPopup) {
    creatorBuildsPopup.onclick = function (e) {
      if (e.target === creatorBuildsPopup) closeCreatorBuilds();
    };
  }

  // Links open through the launcher's bridge, with a browser fallback, so a link
  // button is never dead when the bridge is not there.
  function openExternalUrl(url) {
    try {
      var ex = getExternal();
      if (ex && ex.openUrl) {
        ex.openUrl(url);
        return;
      }
    } catch (e) {}
    try {
      window.open(url, "_blank");
    } catch (e) {}
  }
  window.openExternalUrl = openExternalUrl;

  document.addEventListener("click", function (e) {
    var target = e.target;
    while (target && target !== document.body) {
      if (target.getAttribute && target.getAttribute("data-url")) {
        e.preventDefault();
        openExternalUrl(target.getAttribute("data-url"));
        return;
      }
      target = target.parentNode;
    }
  });

  // The selector starts on Latest and fills in from our own site; a failed fetch
  // leaves it exactly as it looks today.
  _selectedVersion = _selectedVersion || "latest";
  fetchVersions();

  /* CodHQ: the first-run note. Shown once per WebView profile, then remembered. */
  (function codhqWelcome() {
    var popup = document.getElementById("codhqWelcome");
    if (!popup) return;
    var key = "codhq_welcome_v1";
    var seen = null;
    try {
      seen = localStorage.getItem(key);
    } catch (e) {}
    if (seen) return;

    function hide() {
      popup.classList.remove("active");
      try {
        localStorage.setItem(key, "1");
      } catch (e) {}
      var name = document.getElementById("playerName");
      if (name) {
        try {
          name.focus();
        } catch (e) {}
      }
    }

    var close = document.getElementById("codhqWelcomeClose");
    if (close) close.onclick = hide;
    var go = document.getElementById("codhqWelcomeGo");
    if (go) go.onclick = hide;
    popup.onclick = function (e) {
      if (e.target === popup) hide();
    };
    popup.classList.add("active");
  })();

  var creditsPopup = document.getElementById("creditsPopup");
  var versionDisplay = document.getElementById("versionDisplay");
  if (versionDisplay && creditsPopup) {
    versionDisplay.onclick = function () {
      creditsPopup.classList.add("active");
    };
    var creditsClose = creditsPopup.querySelector(".popup-close");
    if (creditsClose) {
      creditsClose.onclick = function () {
        creditsPopup.classList.remove("active");
      };
    }
    creditsPopup.onclick = function (e) {
      if (e.target === creditsPopup) {
        creditsPopup.classList.remove("active");
      }
    };
  }
})();
